package carrental;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.print.*;
import java.io.File;
import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.FontMetrics;

public class Carrental extends JFrame {

    Connection con;
    CardLayout card = new CardLayout();
    JPanel mainPanel = new JPanel(card);

    String currentUserName = "", currentUserContact = "", currentUserEmail = "";
    int currentUserId = 0;
    String imageBasePath = "";

    Color bgBase    = new Color(24, 24, 37);
    Color bgSurface = new Color(30, 30, 46);
    Color bgOverlay = new Color(40, 40, 60);
    Color bgInput   = new Color(50, 50, 75);
    Color blue      = new Color(137, 180, 250);
    Color green     = new Color(166, 227, 161);
    Color red       = new Color(243, 139, 168);
    Color yellow    = new Color(249, 226, 175);
    Color mauve     = new Color(203, 166, 247);
    Color peach     = new Color(250, 179, 135);
    Color teal      = new Color(148, 226, 213);
    Color textMain  = new Color(205, 214, 244);
    Color textSub   = new Color(147, 153, 178);
    Color white     = Color.WHITE;

    static final int DRIVER_RATE_PER_HOUR = 50;
    static final int DEFAULT_MIN_HOURS = 1;
    static final int DEFAULT_MAX_HOURS = 360;

    static final String[] PAYMENT_METHODS = {
        "Cash on Pickup",
        "JazzCash",
        "EasyPaisa",
        "Bank Transfer (HBL)",
        "Bank Transfer (UBL)",
        "Credit / Debit Card"
    };
    static final String[] PAYMENT_ICONS = {
        "\uD83D\uDCB5", "\uD83D\uDCF1", "\uD83D\uDCF1", "\uD83C\uDFE6", "\uD83C\uDFE6", "\uD83D\uDCB3"
    };
    static final String JAZZCASH_ACCOUNT = "0300-1234567";
    static final String EASYPAISA_ACCOUNT = "0321-9876543";
    static final String HBL_ACCOUNT = "HBL-0022-1234-5678";
    static final String UBL_ACCOUNT = "UBL-0033-8765-4321";

    JTextField loginUser = new JTextField(18);
    JPasswordField loginPass = new JPasswordField(18);
    JTextField sName = new JTextField(18), sEmail = new JTextField(18);
    JTextField sUser = new JTextField(18), sContact = new JTextField(18);
    JPasswordField sPass = new JPasswordField(18);
    JCheckBox showPassCheck = new JCheckBox("Show Password");
    JLabel lblNameMsg = new JLabel(" "), lblEmailMsg = new JLabel(" ");
    JLabel lblUserMsg = new JLabel(" "), lblPassMsg = new JLabel(" ");
    JLabel lblContactMsg = new JLabel(" ");
    JLabel profileNameVal = new JLabel(), profileEmailVal = new JLabel();
    JLabel profileContactVal = new JLabel();
    JLabel dashValCars = new JLabel("0"), dashValAvail = new JLabel("0");
    JLabel dashValActive = new JLabel("0"), dashValRevenue = new JLabel("Rs. 0");
    JLabel userTopBarLabel = new JLabel("  ELITE CAR RENTAL - Welcome!");

    DefaultTableModel customerAvailModel = new DefaultTableModel(
        new String[]{"ID","Brand","Model","Rs/Hr","Avail","Image"}, 0) {
        @Override public boolean isCellEditable(int r,int c){return false;}};
    DefaultTableModel userRentalModel = new DefaultTableModel(
        new String[]{"ID","Car","Start","End","Driver","Qty","Bill","Payment","Status","CarID_H"}, 0) {
        @Override public boolean isCellEditable(int r,int c){return false;}};
    DefaultTableModel userHistoryModel = new DefaultTableModel(
        new String[]{"Car","Start","End","Returned","Driver","Qty","Bill","Late Fee","Payment","Status"}, 0) {
        @Override public boolean isCellEditable(int r,int c){return false;}};
    DefaultTableModel adminCarModel = new DefaultTableModel(
        new String[]{"ID","Brand","Model","Rs/Hr","MinHr","MaxHr","Total","Avail","Image"}, 0) {
        @Override public boolean isCellEditable(int r,int c){return false;}};
    DefaultTableModel adminRentalModel = new DefaultTableModel(
        new String[]{"RID","Car","Customer","Contact","Start","End","Driver","Qty","Bill","Late","Payment","PayStatus","Status","CarID_H","UserID_H"}, 0) {
        @Override public boolean isCellEditable(int r,int c){return false;}};
    DefaultTableModel adminUserModel = new DefaultTableModel(
        new String[]{"Name","Contact","Email","Username"}, 0) {
        @Override public boolean isCellEditable(int r,int c){return false;}};
    DefaultTableModel adminHistModel = new DefaultTableModel(
        new String[]{"RID","Car","Customer","Start","End","Returned","Bill","Late","Payment","Status"}, 0) {
        @Override public boolean isCellEditable(int r,int c){return false;}};
    DefaultTableModel dashRecentModel = new DefaultTableModel(
        new String[]{"ID","Car","Customer","Start","End","Payment","Status"}, 0) {
        @Override public boolean isCellEditable(int r,int c){return false;}};

    JTable adminCarTable, adminRentalTable, adminUserTable, adminHistTable;
    JTable userCarTable, userRentTable, userHistTable, dashRecentTable;
    JComboBox<String> adminUserCombo;
    DateTimeFormatter dtfShort = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public Carrental() {
        detectImageBasePath(); connectDB(); initDB();
        setTitle("Elite Car Rental - Affordable Premium Service");
        setSize(1200, 800); setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); getContentPane().setBackground(bgBase);
        mainPanel.setBackground(bgBase);
        mainPanel.add(makeLoginPanel(), "login");
        mainPanel.add(makeSignupPanel(), "signup");
        mainPanel.add(makeAdminPanel(), "admin_page");
        mainPanel.add(makeUserPanel(), "user_page");
        add(mainPanel); card.show(mainPanel, "login");
    }

    // ========================================================================
    //  CALENDAR DATE PICKER
    // ========================================================================
    class CalendarDatePicker extends JPanel {
        private JTextField dateField;
        private JButton calBtn;
        private LocalDate selectedDate;
        private LocalDate minDate;
        private int curYear, curMonth;

        public CalendarDatePicker() { this(null); }
        public CalendarDatePicker(LocalDate minimumDate) {
            setLayout(new BorderLayout(2, 0));
            setBackground(bgSurface);
            this.minDate = minimumDate != null ? minimumDate : LocalDate.now();
            dateField = new JTextField(10);
            dateField.setBackground(bgInput); dateField.setForeground(white);
            dateField.setCaretColor(white); dateField.setEditable(false);
            dateField.setText("Select Date");
            dateField.setHorizontalAlignment(SwingConstants.CENTER);
            dateField.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            dateField.setBorder(BorderFactory.createLineBorder(new Color(80,80,110)));
            calBtn = new JButton("Calendar"); calBtn.setBackground(blue);
            calBtn.setForeground(white); calBtn.setFocusPainted(false);
            calBtn.setBorderPainted(false);
            calBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            calBtn.setPreferredSize(new Dimension(75, 26));
            calBtn.setFont(new Font("Segoe UI", Font.BOLD, 11));
            add(dateField, BorderLayout.CENTER); add(calBtn, BorderLayout.EAST);
            calBtn.addActionListener(e -> showCalendar());
        }
        public void setMinDate(LocalDate min) { this.minDate = min; if (selectedDate != null && selectedDate.isBefore(min)) clear(); }
        public LocalDate getSelectedDate() { return selectedDate; }
        public void clear() { selectedDate = null; dateField.setText("Select Date"); }

        void showCalendar() {
            LocalDate today = LocalDate.now();
            if (selectedDate != null) { curYear = selectedDate.getYear(); curMonth = selectedDate.getMonthValue(); }
            else { curYear = today.getYear(); curMonth = today.getMonthValue(); }
            if (minDate != null && LocalDate.of(curYear, curMonth, 1).isBefore(LocalDate.of(minDate.getYear(), minDate.getMonth(), 1)))
            { curYear = minDate.getYear(); curMonth = minDate.getMonthValue(); }
            JDialog dlg = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Select Date", true);
            dlg.setSize(310, 290); dlg.setResizable(false); dlg.setLocationRelativeTo(calBtn);
            dlg.getContentPane().setBackground(bgSurface); dlg.setLayout(new BorderLayout(5, 5));
            JPanel topP = new JPanel(new BorderLayout()); topP.setBackground(bgOverlay);
            topP.setBorder(BorderFactory.createEmptyBorder(6, 4, 6, 4));
            JButton prevBtn = new JButton("<"); prevBtn.setBackground(bgOverlay); prevBtn.setForeground(white);
            prevBtn.setFocusPainted(false); prevBtn.setBorderPainted(false);
            prevBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
            JLabel monthYearLbl = new JLabel("", SwingConstants.CENTER);
            monthYearLbl.setFont(new Font("Segoe UI", Font.BOLD, 14)); monthYearLbl.setForeground(white);
            JButton nextBtn = new JButton(">"); nextBtn.setBackground(bgOverlay); nextBtn.setForeground(white);
            nextBtn.setFocusPainted(false); nextBtn.setBorderPainted(false);
            nextBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
            topP.add(prevBtn, BorderLayout.WEST); topP.add(monthYearLbl, BorderLayout.CENTER);
            topP.add(nextBtn, BorderLayout.EAST);
            String[] days = {"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
            DefaultTableModel calModel = new DefaultTableModel(days, 6) {
                @Override public boolean isCellEditable(int r, int c) { return false; } };
            JTable calTable = new JTable(calModel);
            calTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            calTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 11));
            calTable.getTableHeader().setBackground(bgOverlay);
            calTable.getTableHeader().setForeground(textMain);
            calTable.setBackground(bgSurface); calTable.setRowHeight(30);
            calTable.setGridColor(new Color(50, 50, 75));
            calTable.setCellSelectionEnabled(true);
            calTable.setSelectionBackground(blue); calTable.setSelectionForeground(white);
            calTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
                @Override public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSel, boolean hasFocus, int row, int col) {
                    JLabel lbl = (JLabel) super.getTableCellRendererComponent(table, value, isSel, hasFocus, row, col);
                    lbl.setHorizontalAlignment(SwingConstants.CENTER);
                    lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                    if (value == null || value.toString().isEmpty()) { lbl.setText(""); lbl.setBackground(bgSurface); return lbl; }
                    try { int day = Integer.parseInt(value.toString());
                        LocalDate cellDate = LocalDate.of(curYear, curMonth, day);
                        lbl.setBackground(bgSurface);
                        if (minDate != null && cellDate.isBefore(minDate))
                        { lbl.setForeground(new Color(80, 80, 105)); lbl.setFont(new Font("Segoe UI", Font.ITALIC, 12)); }
                        else { lbl.setForeground(textMain);
                            if (cellDate.equals(LocalDate.now()))
                            { lbl.setBackground(new Color(40, 60, 85)); lbl.setForeground(yellow); lbl.setFont(new Font("Segoe UI", Font.BOLD, 13)); }
                            if (selectedDate != null && cellDate.equals(selectedDate))
                            { lbl.setBackground(blue); lbl.setForeground(white); lbl.setFont(new Font("Segoe UI", Font.BOLD, 14)); }
                            if (isSel && !(selectedDate != null && cellDate.equals(selectedDate)))
                            { lbl.setBackground(new Color(70, 90, 130)); lbl.setForeground(white); }
                        }
                    } catch (NumberFormatException ex) { lbl.setBackground(bgSurface); } return lbl; } });
            Runnable populate = () -> {
                for (int r = 0; r < 6; r++) for (int c = 0; c < 7; c++) calModel.setValueAt("", r, c);
                YearMonth ym = YearMonth.of(curYear, curMonth);
                int startCol = ym.atDay(1).getDayOfWeek().getValue() % 7;
                int r = 0, c = startCol;
                for (int d = 1; d <= ym.lengthOfMonth(); d++)
                { calModel.setValueAt(d, r, c); c++; if (c >= 7) { c = 0; r++; } }
                String[] mN = {"January","February","March","April","May","June",
                    "July","August","September","October","November","December"};
                monthYearLbl.setText(mN[curMonth - 1] + " " + curYear); };
            populate.run();
            calTable.addMouseListener(new MouseAdapter() { public void mouseClicked(MouseEvent e) {
                int r = calTable.getSelectedRow(); int c = calTable.getSelectedColumn();
                Object val = calModel.getValueAt(r, c);
                if (val == null || val.toString().isEmpty()) return;
                try { int day = Integer.parseInt(val.toString());
                    LocalDate clicked = LocalDate.of(curYear, curMonth, day);
                    if (minDate != null && clicked.isBefore(minDate))
                    { JOptionPane.showMessageDialog(dlg, "Cannot select past dates!", "Invalid", JOptionPane.WARNING_MESSAGE); return; }
                    selectedDate = clicked;
                    dateField.setText(clicked.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
                    dlg.dispose();
                } catch (NumberFormatException ex) {} } });
            prevBtn.addActionListener(ev -> { curMonth--; if (curMonth < 1) { curMonth = 12; curYear--; }
                if (minDate != null && LocalDate.of(curYear, curMonth, 1).isBefore(LocalDate.of(minDate.getYear(), minDate.getMonth(), 1)))
                { curYear = minDate.getYear(); curMonth = minDate.getMonthValue(); } populate.run(); });
            nextBtn.addActionListener(ev -> { curMonth++; if (curMonth > 12) { curMonth = 1; curYear++; } populate.run(); });
            JButton todayBtn = new JButton("Today"); todayBtn.setBackground(green);
            todayBtn.setForeground(white); todayBtn.setFocusPainted(false);
            todayBtn.setBorderPainted(false);
            todayBtn.setFont(new Font("Segoe UI", Font.BOLD, 11));
            todayBtn.addActionListener(ev -> { curYear = LocalDate.now().getYear();
                curMonth = LocalDate.now().getMonthValue(); populate.run(); });
            JPanel bottomP = new JPanel(); bottomP.setBackground(bgSurface); bottomP.add(todayBtn);
            JScrollPane sp = new JScrollPane(calTable); sp.getViewport().setBackground(bgSurface); sp.setBorder(null);
            dlg.add(topP, BorderLayout.NORTH); dlg.add(sp, BorderLayout.CENTER);
            dlg.add(bottomP, BorderLayout.SOUTH); dlg.setVisible(true);
        }
    }

    void detectImageBasePath() {
        String[] candidates = {"src/carrental/car_images/","car_images/","carrental/car_images/"};
        for (String c : candidates) { if (new File(c).exists()) { imageBasePath = c; return; } }
        String ud = System.getProperty("user.dir");
        String[] abs = {ud + "/src/carrental/car_images/", ud + "/car_images/"};
        for (String c : abs) { if (new File(c).exists()) { imageBasePath = c; return; } }
        imageBasePath = "src/carrental/car_images/";
    }
    String resolveImage(String filename) {
        if (filename == null || filename.isEmpty()) return "";
        File f = new File(filename); if (f.exists()) return filename;
        f = new File(imageBasePath + filename); if (f.exists()) return f.getAbsolutePath();
        f = new File(imageBasePath + new File(filename).getName());
        if (f.exists()) return f.getAbsolutePath(); return filename;
    }
    final void connectDB() {
        try { Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_rental","root","");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "DB failed: " + e.getMessage()); }
    }

    void initDB() {
        try { Statement st = con.createStatement();
            st.execute("CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY," +
                "name VARCHAR(100) NOT NULL,email VARCHAR(100) NOT NULL," +
                "username VARCHAR(50) UNIQUE NOT NULL,password VARCHAR(100) NOT NULL," +
                "role VARCHAR(20) DEFAULT 'Customer',contact VARCHAR(20) NOT NULL)");
            st.execute("CREATE TABLE IF NOT EXISTS cars (id INT AUTO_INCREMENT PRIMARY KEY," +
                "name VARCHAR(100) NOT NULL,model VARCHAR(100) NOT NULL," +
                "price_per_hour DOUBLE NOT NULL,min_hours INT DEFAULT 1," +
                "max_hours INT DEFAULT 360,total_qty INT DEFAULT 1," +
                "available_qty INT DEFAULT 1,img_path VARCHAR(500))");
            st.execute("CREATE TABLE IF NOT EXISTS rentals (id INT AUTO_INCREMENT PRIMARY KEY," +
                "car_id INT NOT NULL,user_id INT NOT NULL,customer_name VARCHAR(100)," +
                "contact VARCHAR(20),rent_start DATETIME NOT NULL,rent_end DATETIME NOT NULL," +
                "actual_return DATETIME,total_price DOUBLE,late_fee DOUBLE DEFAULT 0," +
                "has_driver BOOLEAN DEFAULT FALSE,quantity INT DEFAULT 1," +
                "status VARCHAR(20) DEFAULT 'Active'," +
                "payment_method VARCHAR(50) DEFAULT 'Cash on Pickup'," +
                "payment_status VARCHAR(20) DEFAULT 'Pending'," +
                "FOREIGN KEY (car_id) REFERENCES cars(id)," +
                "FOREIGN KEY (user_id) REFERENCES users(id))");

            try { st.executeUpdate("ALTER TABLE rentals ADD COLUMN payment_method VARCHAR(50) DEFAULT 'Cash on Pickup'"); } catch(SQLException ex) {}
            try { st.executeUpdate("ALTER TABLE rentals ADD COLUMN payment_status VARCHAR(20) DEFAULT 'Pending'"); } catch(SQLException ex) {}

            ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM users WHERE username='MashalRazzaq'");
            rs.next();
            if (rs.getInt(1) == 0)
                st.execute("INSERT INTO users(name,email,username,password,role,contact) " +
                    "VALUES('Mashal Razzaq','admin@eliterental.com','MashalRazzaq','123456','Admin','03001234567')");

            rs = st.executeQuery("SELECT COUNT(*) FROM cars"); rs.next();
            int carCount = rs.getInt(1);
            if (carCount == 0) {
                String ibp = imageBasePath;
                String[][] cars = {
                    {"Suzuki Alto","VX","50","1","360","5","5","Suzuki Alto.jpg"},
                    {"Suzuki Alto","VXR","65","1","360","5","5","Suzuki Alto.jpg"},
                    {"Toyota Corolla","2024 GLi","120","1","360","5","5","Toyota Corolla.jpg"},
                    {"Toyota Corolla","2024 XLi","140","1","360","5","5","Toyota Corolla.jpg"},
                    {"Honda City","Aspire","150","1","360","5","5","Honda City.jpg"},
                    {"Toyota Yaris","ATIV X","130","1","360","5","5","Toyota Yaris.jpg"},
                    {"Toyota Yaris","ATIV S","150","1","360","5","5","Toyota Yaris.jpg"},
                    {"Honda Civic","2024 Oriel","200","1","360","5","5","Honda Civic.jpg"},
                    {"Honda Civic","2024 Turbo","230","1","360","5","5","Honda Civic.jpg"},
                    {"Kia Sportage","Alpha","250","1","360","3","3","Kia Sportage.jpg"},
                    {"Hyundai Tucson","GLS","280","1","360","3","3","Hyundai Tucson.jpg"},
                    {"Audi","A6","400","1","360","3","3","Audi A6.jpg"},
                    {"Mercedes","C200","400","1","360","2","2","Mercedes C-Class.jpg"},
                    {"Mercedes","C300","500","1","360","2","2","Mercedes C-Class.jpg"},
                    {"BMW","M4","500","1","360","3","3","BMW M4.jpg"},
                    {"Tesla","Model S","600","2","360","2","2","Tesla model s.jpg"},
                    {"Ferrari","488","1000","2","360","2","2","Ferrari488.jpg"},
                };
                PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO cars(name,model,price_per_hour,min_hours,max_hours," +
                    "total_qty,available_qty,img_path) VALUES(?,?,?,?,?,?,?,?)");
                for (String[] c : cars) {
                    ps.setString(1,c[0]); ps.setString(2,c[1]);
                    ps.setDouble(3,Double.parseDouble(c[2]));
                    ps.setInt(4,Integer.parseInt(c[3])); ps.setInt(5,Integer.parseInt(c[4]));
                    ps.setInt(6,Integer.parseInt(c[5])); ps.setInt(7,Integer.parseInt(c[6]));
                    File imgF = new File(ibp+c[7]);
                    ps.setString(8, imgF.exists() ? imgF.getAbsolutePath() : ibp+c[7]);
                    ps.executeUpdate();
                }
            } else {
                try {
                    st.executeUpdate("UPDATE cars SET min_hours=1, max_hours=360 WHERE min_hours > 1 OR max_hours < 360");
                    st.executeUpdate("UPDATE cars SET price_per_hour=50  WHERE name='Suzuki Alto' AND model='VX'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=65  WHERE name='Suzuki Alto' AND model='VXR'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=120 WHERE name='Toyota Corolla' AND model='2024 GLi'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=140 WHERE name='Toyota Corolla' AND model='2024 XLi'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=150 WHERE name='Honda City' AND model='Aspire'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=130 WHERE name='Toyota Yaris' AND model='ATIV X'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=150 WHERE name='Toyota Yaris' AND model='ATIV S'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=200 WHERE name='Honda Civic' AND model='2024 Oriel'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=230 WHERE name='Honda Civic' AND model='2024 Turbo'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=250 WHERE name='Kia Sportage' AND model='Alpha'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=280 WHERE name='Hyundai Tucson' AND model='GLS'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=400 WHERE name='Audi' AND model='A6'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=400 WHERE name='Mercedes' AND model='C200'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=500 WHERE name='Mercedes' AND model='C300'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=500 WHERE name='BMW' AND model='M4'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=600, min_hours=2 WHERE name='Tesla' AND model='Model S'");
                    st.executeUpdate("UPDATE cars SET price_per_hour=1000, min_hours=2 WHERE name='Ferrari' AND model='488'");
                } catch(Exception ex) { ex.printStackTrace(); }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    JButton styledBtn(String text, Color bg) {
        JButton b = new JButton(text); b.setBackground(bg); b.setForeground(white);
        b.setFont(new Font("Segoe UI",Font.BOLD,12)); b.setFocusPainted(false);
        b.setBorderPainted(false); b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(155,34)); return b;
    }
    JLabel lbl(String text) {
        JLabel l = new JLabel(text); l.setForeground(textMain);
        l.setFont(new Font("Segoe UI",Font.PLAIN,13)); return l;
    }
    void styleTable(JTable t) {
        t.setFont(new Font("Segoe UI",Font.PLAIN,12));
        t.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        t.getTableHeader().setBackground(bgOverlay);
        t.getTableHeader().setForeground(textMain);
        t.setBackground(bgSurface); t.setForeground(textMain);
        t.setGridColor(new Color(60,60,85));
        if (t.getRowHeight() < 30) t.setRowHeight(30);
        t.setSelectionBackground(new Color(70,80,120));
        t.setSelectionForeground(white);
    }
    
    void setupCarImageTable(JTable table, int imageColIndex) {
        table.setRowHeight(130);
        table.getColumnModel().getColumn(imageColIndex).setPreferredWidth(220);
        table.getColumnModel().getColumn(imageColIndex).setMinWidth(200);
        table.getColumnModel().getColumn(imageColIndex).setMaxWidth(250);
        table.setIntercellSpacing(new Dimension(3, 3));
    }
    
    void styleTabbedPane(JTabbedPane tp) {
        tp.setBackground(bgSurface); tp.setForeground(textMain);
        tp.setFont(new Font("Segoe UI",Font.BOLD,13));
    }
    JPanel statsCard(String icon, JLabel valLbl, String label, Color accent) {
        JPanel card = new JPanel(new BorderLayout(6,2)); card.setBackground(bgOverlay);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(accent,1),
            BorderFactory.createEmptyBorder(12,16,12,16)));
        JLabel iconLbl = new JLabel(icon);
        iconLbl.setFont(new Font("Segoe UI Emoji",Font.PLAIN,26)); iconLbl.setForeground(accent);
        valLbl.setFont(new Font("Segoe UI",Font.BOLD,22)); valLbl.setForeground(white);
        JLabel lblTxt = new JLabel(label); lblTxt.setFont(new Font("Segoe UI",Font.PLAIN,11));
        lblTxt.setForeground(textSub);
        JPanel textP = new JPanel(new BorderLayout()); textP.setBackground(bgOverlay);
        textP.add(valLbl,BorderLayout.NORTH); textP.add(lblTxt,BorderLayout.SOUTH);
        card.add(iconLbl,BorderLayout.WEST); card.add(textP,BorderLayout.CENTER); return card;
    }

    class ImageRenderer extends DefaultTableCellRenderer {
        private final int IMG_WIDTH = 200;
        private final int IMG_HEIGHT = 110;
        private final int PAD = 6;

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {

            JPanel cell = new JPanel(new BorderLayout());
            cell.setOpaque(true);
            cell.setBorder(BorderFactory.createEmptyBorder(PAD, PAD, PAD, PAD));

            Color bgNorm = new Color(35, 35, 55);
            Color bgSel  = new Color(55, 75, 120);
            cell.setBackground(isSelected ? bgSel : bgNorm);

            JPanel imgHolder = new JPanel(new BorderLayout());
            imgHolder.setOpaque(false);
            imgHolder.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(isSelected ? new Color(137,180,250) : new Color(70,70,100), 1, true),
                BorderFactory.createEmptyBorder(2, 2, 2, 2)));

            boolean found = false;
            if (value != null && !value.toString().isEmpty()) {
                String path = resolveImage(value.toString());
                File f = new File(path);
                if (f.exists()) {
                    ImageIcon icon = new ImageIcon(path);
                    Image img = icon.getImage();

                    BufferedImage scaled = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, BufferedImage.TYPE_INT_ARGB);
                    Graphics2D g2 = scaled.createGraphics();
                    g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                    g2.setColor(new Color(24, 24, 37));
                    g2.fillRect(0, 0, IMG_WIDTH, IMG_HEIGHT);

                    int origW = icon.getIconWidth();
                    int origH = icon.getIconHeight();
                    if (origW > 0 && origH > 0) {
                        double scale = Math.min((double) IMG_WIDTH / origW, (double) IMG_HEIGHT / origH);
                        int drawW = (int) (origW * scale);
                        int drawH = (int) (origH * scale);
                        int x = (IMG_WIDTH - drawW) / 2;
                        int y = (IMG_HEIGHT - drawH) / 2;
                        g2.drawImage(img, x, y, drawW, drawH, null);
                    }
                    g2.dispose();

                    JLabel imgLbl = new JLabel(new ImageIcon(scaled));
                    imgLbl.setHorizontalAlignment(SwingConstants.CENTER);
                    imgLbl.setOpaque(false);
                    imgHolder.add(imgLbl, BorderLayout.CENTER);
                    found = true;
                }
            }

            if (!found) {
                BufferedImage placeholder = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2 = placeholder.createGraphics();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(40, 40, 60));
                g2.fillRect(0, 0, IMG_WIDTH, IMG_HEIGHT);

                g2.setColor(new Color(70, 70, 100));
                g2.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
                FontMetrics fm = g2.getFontMetrics();
                String carEmoji = "\uD83D\uDE97";
                int emojiW = fm.stringWidth(carEmoji);
                g2.drawString(carEmoji, (IMG_WIDTH - emojiW) / 2, IMG_HEIGHT / 2 - 5);

                g2.setColor(new Color(100, 100, 135));
                g2.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                FontMetrics fm2 = g2.getFontMetrics();
                String txt = "No Image Available";
                int txtW = fm2.stringWidth(txt);
                g2.drawString(txt, (IMG_WIDTH - txtW) / 2, IMG_HEIGHT / 2 + 25);
                g2.dispose();

                JLabel phLbl = new JLabel(new ImageIcon(placeholder));
                phLbl.setHorizontalAlignment(SwingConstants.CENTER);
                phLbl.setOpaque(false);
                imgHolder.add(phLbl, BorderLayout.CENTER);
            }

            cell.add(imgHolder, BorderLayout.CENTER);
            return cell;
        }
    }
    
    class StatusRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel label = (JLabel)super.getTableCellRendererComponent(table,value,isSelected,hasFocus,row,column);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setFont(new Font("Segoe UI",Font.BOLD,11));
            String status = value!=null?value.toString():"";
            switch(status) {
                case "Active": label.setForeground(green); label.setText("● Active"); break;
                case "Returned": label.setForeground(blue); label.setText("● Returned"); break;
                case "Cancelled": label.setForeground(red); label.setText("● Cancelled"); break;
                default: label.setForeground(textSub);
            }
            return label;
        }
    }
    class PaymentMethodRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel label = (JLabel)super.getTableCellRendererComponent(table,value,isSelected,hasFocus,row,column);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setFont(new Font("Segoe UI",Font.BOLD,11));
            String pm = value!=null?value.toString():"";
            switch(pm) {
                case "JazzCash": label.setForeground(new Color(237,28,36)); label.setText("JazzCash"); break;
                case "EasyPaisa": label.setForeground(new Color(54,176,69)); label.setText("EasyPaisa"); break;
                case "Bank Transfer (HBL)": label.setForeground(new Color(0,102,178)); label.setText("HBL Transfer"); break;
                case "Bank Transfer (UBL)": label.setForeground(new Color(0,102,51)); label.setText("UBL Transfer"); break;
                case "Credit / Debit Card": label.setForeground(mauve); label.setText("Card"); break;
                default: label.setForeground(yellow); label.setText("Cash"); break;
            }
            return label;
        }
    }
    class PayStatusRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel label = (JLabel)super.getTableCellRendererComponent(table,value,isSelected,hasFocus,row,column);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setFont(new Font("Segoe UI",Font.BOLD,11));
            String ps = value!=null?value.toString():"";
            switch(ps) {
                case "Paid": label.setForeground(green); label.setText("Paid"); break;
                case "Pending": label.setForeground(yellow); label.setText("Pending"); break;
                case "Failed": label.setForeground(red); label.setText("Failed"); break;
                default: label.setForeground(textSub);
            }
            return label;
        }
    }

    // ========================================================================
    //  PAYMENT SYSTEM
    // ========================================================================
    class PaymentResult {
        String method;
        String status;
        String accountNumber;
        String transactionRef;
        PaymentResult(String method, String status, String acc, String ref) {
            this.method = method; this.status = status;
            this.accountNumber = acc; this.transactionRef = ref;
        }
    }

    PaymentResult lastPaymentResult = new PaymentResult("Cash on Pickup", "Cancelled", "", "");

    PaymentResult showPaymentDialog(double totalAmount, String carInfo) {
        JDialog dlg = new JDialog(this, "Complete Payment", true);
        dlg.setSize(520, 650); dlg.setResizable(false);
        dlg.setLocationRelativeTo(this);
        dlg.getContentPane().setBackground(bgSurface);
        dlg.setLayout(new BorderLayout(10, 10));

        JPanel headerP = new JPanel();
        headerP.setBackground(bgOverlay);
        headerP.setLayout(new BoxLayout(headerP, BoxLayout.Y_AXIS));
        headerP.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        JLabel hTitle = new JLabel("PAYMENT", SwingConstants.CENTER);
        hTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        hTitle.setForeground(blue); hTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel hCar = new JLabel(carInfo, SwingConstants.CENTER);
        hCar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        hCar.setForeground(textSub); hCar.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel hAmount = new JLabel(String.format("Total: Rs. %,.2f", totalAmount), SwingConstants.CENTER);
        hAmount.setFont(new Font("Segoe UI", Font.BOLD, 20));
        hAmount.setForeground(green); hAmount.setAlignmentX(Component.CENTER_ALIGNMENT);
        headerP.add(hTitle); headerP.add(Box.createVerticalStrut(5));
        headerP.add(hCar); headerP.add(Box.createVerticalStrut(5));
        headerP.add(hAmount);
        dlg.add(headerP, BorderLayout.NORTH);

        CardLayout payCard = new CardLayout();
        JPanel centerP = new JPanel(payCard);
        centerP.setBackground(bgSurface);
        centerP.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JPanel selectP = new JPanel();
        selectP.setLayout(new BoxLayout(selectP, BoxLayout.Y_AXIS));
        selectP.setBackground(bgSurface);
        JLabel selTitle = new JLabel("Select Payment Method");
        selTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        selTitle.setForeground(textMain); selTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        selectP.add(selTitle); selectP.add(Box.createVerticalStrut(12));

        Color[] methodColors = {yellow, new Color(237,28,36), new Color(54,176,69),
            new Color(0,102,178), new Color(0,102,51), mauve};
        for (int i = 0; i < PAYMENT_METHODS.length; i++) {
            JButton mb = new JButton("  " + PAYMENT_METHODS[i]);
            mb.setBackground(methodColors[i]); mb.setForeground(white);
            mb.setFont(new Font("Segoe UI", Font.BOLD, 14));
            mb.setFocusPainted(false); mb.setBorderPainted(false);
            mb.setCursor(new Cursor(Cursor.HAND_CURSOR));
            mb.setMaximumSize(new Dimension(350, 45));
            mb.setAlignmentX(Component.CENTER_ALIGNMENT);
            final int idx = i;
            mb.addActionListener(ev -> payCard.show(centerP, PAYMENT_METHODS[idx]));
            selectP.add(mb); selectP.add(Box.createVerticalStrut(8));
        }
        centerP.add(selectP, "select");

        centerP.add(createOnlinePayPanel("JazzCash", JAZZCASH_ACCOUNT,
            "Send Rs. " + String.format("%,.0f", totalAmount) + " to:",
            "JazzCash", payCard, centerP, dlg), "JazzCash");

        centerP.add(createOnlinePayPanel("EasyPaisa", EASYPAISA_ACCOUNT,
            "Send Rs. " + String.format("%,.0f", totalAmount) + " to:",
            "EasyPaisa", payCard, centerP, dlg), "EasyPaisa");

        centerP.add(createOnlinePayPanel("Bank Transfer (HBL)", HBL_ACCOUNT,
            "Transfer Rs. " + String.format("%,.0f", totalAmount) + " to:",
            "Bank Transfer (HBL)", payCard, centerP, dlg), "Bank Transfer (HBL)");

        centerP.add(createOnlinePayPanel("Bank Transfer (UBL)", UBL_ACCOUNT,
            "Transfer Rs. " + String.format("%,.0f", totalAmount) + " to:",
            "Bank Transfer (UBL)", payCard, centerP, dlg), "Bank Transfer (UBL)");

        centerP.add(createCardPaymentPanel(totalAmount, payCard, centerP, dlg),
            "Credit / Debit Card");

        centerP.add(createCashPaymentPanel(totalAmount, payCard, centerP, dlg),
            "Cash on Pickup");

        dlg.add(centerP, BorderLayout.CENTER);
        payCard.show(centerP, "select");

        lastPaymentResult = new PaymentResult("Cash on Pickup", "Cancelled", "", "");

        JPanel bottomP = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 8));
        bottomP.setBackground(bgOverlay);
        bottomP.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        JButton cancelBtn = styledBtn("CANCEL PAYMENT", red);
        cancelBtn.addActionListener(ev -> {
            lastPaymentResult = new PaymentResult("Cash on Pickup", "Cancelled", "", "");
            dlg.dispose();
        });
        bottomP.add(cancelBtn);
        dlg.add(bottomP, BorderLayout.SOUTH);

        dlg.setVisible(true);
        return lastPaymentResult;
    }

    JPanel createOnlinePayPanel(String methodName, String accountNum,
            String instruction, String cardName,
            CardLayout payCard, JPanel centerP, JDialog parentDlg) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(bgSurface);
        p.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel backLbl = new JLabel("<< Back to Methods");
        backLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        backLbl.setForeground(blue);
        backLbl.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        backLbl.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { payCard.show(centerP, "select"); }
        });
        p.add(backLbl); p.add(Box.createVerticalStrut(10));

        JLabel titleLbl = new JLabel(methodName, SwingConstants.CENTER);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLbl.setForeground(white); titleLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(titleLbl); p.add(Box.createVerticalStrut(12));

        JPanel infoBox = new JPanel(new BorderLayout(5, 5));
        infoBox.setBackground(bgOverlay);
        infoBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(blue, 1),
            BorderFactory.createEmptyBorder(12, 15, 12, 15)));
        infoBox.setMaximumSize(new Dimension(400, 80));
        infoBox.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel instLbl = new JLabel(instruction);
        instLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        instLbl.setForeground(textSub);
        JLabel accLbl = new JLabel(accountNum);
        accLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        accLbl.setForeground(green);
        JLabel noteLbl = new JLabel("(Elite Car Rental Account)");
        noteLbl.setFont(new Font("Segoe UI", Font.ITALIC, 10));
        noteLbl.setForeground(textSub);
        infoBox.add(instLbl, BorderLayout.NORTH);
        infoBox.add(accLbl, BorderLayout.CENTER);
        infoBox.add(noteLbl, BorderLayout.SOUTH);
        p.add(infoBox); p.add(Box.createVerticalStrut(15));

        JLabel yourAccLbl = new JLabel("Your " + methodName + " Account Number:");
        yourAccLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        yourAccLbl.setForeground(textMain); yourAccLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(yourAccLbl);
        JTextField yourAccField = new JTextField(20);
        yourAccField.setBackground(bgInput); yourAccField.setForeground(white);
        yourAccField.setCaretColor(white);
        yourAccField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        yourAccField.setHorizontalAlignment(JTextField.CENTER);
        yourAccField.setMaximumSize(new Dimension(300, 32));
        yourAccField.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(yourAccField); p.add(Box.createVerticalStrut(10));

        JLabel refLbl = new JLabel("Transaction Reference / TRX ID:");
        refLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        refLbl.setForeground(textMain); refLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(refLbl);
        JTextField refField = new JTextField(20);
        refField.setBackground(bgInput); refField.setForeground(white);
        refField.setCaretColor(white);
        refField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        refField.setHorizontalAlignment(JTextField.CENTER);
        refField.setMaximumSize(new Dimension(300, 32));
        refField.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(refField); p.add(Box.createVerticalStrut(15));

        JButton paidBtn = styledBtn("I HAVE PAID", green);
        paidBtn.setMaximumSize(new Dimension(300, 40));
        paidBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        paidBtn.addActionListener(ev -> {
            String acc = yourAccField.getText().trim();
            String ref = refField.getText().trim();
            if (acc.isEmpty()) { JOptionPane.showMessageDialog(p, "Enter your account number!"); return; }
            if (ref.isEmpty()) { JOptionPane.showMessageDialog(p, "Enter transaction reference!"); return; }

            final JDialog processing = new JDialog(parentDlg, "Processing", false);
            processing.setSize(300, 120); processing.setLocationRelativeTo(p);
            processing.getContentPane().setBackground(bgSurface);
            JLabel procLbl = new JLabel("Verifying payment...", SwingConstants.CENTER);
            procLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
            procLbl.setForeground(textMain);
            processing.add(procLbl); processing.setVisible(true);

            Timer timer = new Timer(2000, te -> {
                processing.dispose();
                JOptionPane.showMessageDialog(p,
                    "Payment Submitted!\nMethod: " + methodName +
                    "\nRef: " + ref +
                    "\n\nYour rental will be confirmed once payment is verified.",
                    "Payment Submitted", JOptionPane.INFORMATION_MESSAGE);
                lastPaymentResult = new PaymentResult(methodName, "Pending", acc, ref);
                parentDlg.dispose();
            });
            timer.setRepeats(false); timer.start();
        });
        p.add(paidBtn);

        return p;
    }

    JPanel createCardPaymentPanel(double totalAmount, CardLayout payCard,
            JPanel centerP, JDialog parentDlg) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(bgSurface);
        p.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel backLbl = new JLabel("<< Back to Methods");
        backLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        backLbl.setForeground(blue);
        backLbl.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        backLbl.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { payCard.show(centerP, "select"); }
        });
        p.add(backLbl); p.add(Box.createVerticalStrut(10));

        JLabel titleLbl = new JLabel("Credit / Debit Card", SwingConstants.CENTER);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLbl.setForeground(white); titleLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(titleLbl); p.add(Box.createVerticalStrut(12));

        JLabel cnLbl = new JLabel("Card Number:");
        cnLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cnLbl.setForeground(textMain); cnLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(cnLbl);
        JTextField cardNumField = new JTextField(20);
        cardNumField.setBackground(bgInput); cardNumField.setForeground(white);
        cardNumField.setCaretColor(white);
        cardNumField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cardNumField.setHorizontalAlignment(JTextField.CENTER);
        cardNumField.setMaximumSize(new Dimension(320, 32));
        cardNumField.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(cardNumField); p.add(Box.createVerticalStrut(8));

        JPanel expCvvP = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        expCvvP.setBackground(bgSurface);
        expCvvP.setMaximumSize(new Dimension(350, 50));
        expCvvP.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel expLbl = new JLabel("Expiry:"); expLbl.setForeground(textMain);
        expLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JTextField expField = new JTextField(5);
        expField.setBackground(bgInput); expField.setForeground(white);
        expField.setCaretColor(white);
        expField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JLabel cvvLbl = new JLabel("CVV:"); cvvLbl.setForeground(textMain);
        cvvLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        JTextField cvvField = new JTextField(3);
        cvvField.setBackground(bgInput); cvvField.setForeground(white);
        cvvField.setCaretColor(white);
        cvvField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        expCvvP.add(expLbl); expCvvP.add(expField);
        expCvvP.add(cvvLbl); expCvvP.add(cvvField);
        p.add(expCvvP); p.add(Box.createVerticalStrut(8));

        JLabel chLbl = new JLabel("Cardholder Name:");
        chLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        chLbl.setForeground(textMain); chLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(chLbl);
        JTextField chNameField = new JTextField(20);
        chNameField.setBackground(bgInput); chNameField.setForeground(white);
        chNameField.setCaretColor(white);
        chNameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chNameField.setHorizontalAlignment(JTextField.CENTER);
        chNameField.setMaximumSize(new Dimension(320, 32));
        chNameField.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(chNameField); p.add(Box.createVerticalStrut(12));

        JLabel amtLbl = new JLabel(String.format("Amount: Rs. %,.2f", totalAmount), SwingConstants.CENTER);
        amtLbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        amtLbl.setForeground(green); amtLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(amtLbl); p.add(Box.createVerticalStrut(12));

        JButton payBtn = styledBtn("PAY NOW", green);
        payBtn.setMaximumSize(new Dimension(300, 40));
        payBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        payBtn.addActionListener(ev -> {
            String cardNum = cardNumField.getText().trim();
            String expiry = expField.getText().trim();
            String cvv = cvvField.getText().trim();
            String chName = chNameField.getText().trim();
            if (cardNum.length() < 16 || !cardNum.replace(" ","").matches("\\d{16}")) {
                JOptionPane.showMessageDialog(p, "Enter valid 16-digit card number!"); return; }
            if (!expiry.matches("\\d{2}/\\d{2}")) {
                JOptionPane.showMessageDialog(p, "Enter expiry as MM/YY!"); return; }
            if (cvv.length() < 3 || !cvv.matches("\\d{3,4}")) {
                JOptionPane.showMessageDialog(p, "Enter valid CVV!"); return; }
            if (chName.isEmpty()) {
                JOptionPane.showMessageDialog(p, "Enter cardholder name!"); return; }

            final JDialog processing = new JDialog(parentDlg, "Processing", false);
            processing.setSize(300, 120); processing.setLocationRelativeTo(p);
            processing.getContentPane().setBackground(bgSurface);
            JLabel procLbl = new JLabel("Processing card payment...", SwingConstants.CENTER);
            procLbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
            procLbl.setForeground(textMain);
            processing.add(procLbl); processing.setVisible(true);

            Timer timer = new Timer(2500, te -> {
                processing.dispose();
                boolean success = Math.random() > 0.1;
                if (success) {
                    String txnId = "TXN" + System.currentTimeMillis() % 100000000;
                    JOptionPane.showMessageDialog(p,
                        "Payment Successful!\nCard: ****" + cardNum.substring(cardNum.length()-4) +
                        "\nAmount: Rs. " + String.format("%,.2f", totalAmount) +
                        "\nRef: " + txnId,
                        "Payment Confirmed", JOptionPane.INFORMATION_MESSAGE);
                    lastPaymentResult = new PaymentResult("Credit / Debit Card", "Paid",
                        "****" + cardNum.substring(cardNum.length()-4), txnId);
                    parentDlg.dispose();
                } else {
                    JOptionPane.showMessageDialog(p,
                        "Payment Failed!\nCard was declined. Please try another method.",
                        "Payment Failed", JOptionPane.ERROR_MESSAGE);
                    lastPaymentResult = new PaymentResult("Credit / Debit Card", "Failed",
                        "****" + cardNum.substring(cardNum.length()-4), "");
                    payCard.show(centerP, "select");
                }
            });
            timer.setRepeats(false); timer.start();
        });
        p.add(payBtn); p.add(Box.createVerticalStrut(8));
        JLabel secureLbl = new JLabel("Secure payment | Cards are not stored", SwingConstants.CENTER);
        secureLbl.setFont(new Font("Segoe UI", Font.ITALIC, 10));
        secureLbl.setForeground(textSub); secureLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(secureLbl);

        return p;
    }

    JPanel createCashPaymentPanel(double totalAmount, CardLayout payCard,
            JPanel centerP, JDialog parentDlg) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setBackground(bgSurface);
        p.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        JLabel backLbl = new JLabel("<< Back to Methods");
        backLbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        backLbl.setForeground(blue);
        backLbl.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        backLbl.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { payCard.show(centerP, "select"); }
        });
        p.add(backLbl); p.add(Box.createVerticalStrut(10));

        JLabel titleLbl = new JLabel("Cash on Pickup", SwingConstants.CENTER);
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLbl.setForeground(white); titleLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(titleLbl); p.add(Box.createVerticalStrut(15));

        JPanel infoBox = new JPanel();
        infoBox.setLayout(new BoxLayout(infoBox, BoxLayout.Y_AXIS));
        infoBox.setBackground(bgOverlay);
        infoBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(yellow, 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)));
        infoBox.setMaximumSize(new Dimension(400, 150));
        infoBox.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel info1 = new JLabel("Pay when you pick up the car");
        info1.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        info1.setForeground(textMain); info1.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel info2 = new JLabel(String.format("Amount Due: Rs. %,.2f", totalAmount));
        info2.setFont(new Font("Segoe UI", Font.BOLD, 16));
        info2.setForeground(yellow); info2.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel info3 = new JLabel("Please bring exact change");
        info3.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        info3.setForeground(textSub); info3.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel info4 = new JLabel("Cash payment will be marked as Pending");
        info4.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        info4.setForeground(textSub); info4.setAlignmentX(Component.CENTER_ALIGNMENT);
        infoBox.add(info1); infoBox.add(Box.createVerticalStrut(8));
        infoBox.add(info2); infoBox.add(Box.createVerticalStrut(5));
        infoBox.add(info3); infoBox.add(Box.createVerticalStrut(3));
        infoBox.add(info4);
        p.add(infoBox); p.add(Box.createVerticalStrut(20));

        JButton confirmBtn = styledBtn("CONFIRM CASH PAYMENT", yellow);
        confirmBtn.setMaximumSize(new Dimension(350, 40));
        confirmBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        confirmBtn.addActionListener(ev -> {
            lastPaymentResult = new PaymentResult("Cash on Pickup", "Pending", "", "");
            parentDlg.dispose();
        });
        p.add(confirmBtn);

        return p;
    }

    void showPaymentStatusDialog(int rentalId, String currentStatus) {
        String[] options = {"Paid", "Pending", "Failed"};
        JComboBox<String> statusCombo = new JComboBox<>(options);
        statusCombo.setSelectedItem(currentStatus);
        statusCombo.setBackground(bgInput); statusCombo.setForeground(white);

        JPanel p = new JPanel(new GridLayout(2, 2, 8, 8));
        p.setBackground(bgSurface);
        p.add(lbl("Rental ID:")); p.add(lbl(String.valueOf(rentalId)));
        p.add(lbl("Payment Status:")); p.add(statusCombo);

        if (JOptionPane.showConfirmDialog(this, p, "Update Payment Status",
                JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
            try {
                PreparedStatement ps = con.prepareStatement("UPDATE rentals SET payment_status=? WHERE id=?");
                ps.setString(1, (String) statusCombo.getSelectedItem());
                ps.setInt(2, rentalId); ps.executeUpdate();
                refreshAdminRentals(); refreshAdminHistory(); refreshDashboard();
                JOptionPane.showMessageDialog(this, "Payment status updated!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }
    }

    void showReceipt(int rentalId) {
        try {
            PreparedStatement ps = con.prepareStatement(
                "SELECT r.*,c.name AS car_name,c.model AS car_model,c.price_per_hour," +
                "u.name AS user_name,u.contact AS user_contact,u.email AS user_email " +
                "FROM rentals r JOIN cars c ON r.car_id=c.id " +
                "JOIN users u ON r.user_id=u.id WHERE r.id=?");
            ps.setInt(1, rentalId); ResultSet rs = ps.executeQuery();
            if (!rs.next()) return;

            String rId = "RNT-"+String.format("%05d", rs.getInt("id"));
            String custName = rs.getString("user_name");
            String custContact = rs.getString("user_contact");
            String custEmail = rs.getString("user_email");
            String carName = rs.getString("car_name");
            String carModel = rs.getString("car_model");
            double priceHr = rs.getDouble("price_per_hour");
            int qty = rs.getInt("quantity");
            LocalDateTime start = rs.getTimestamp("rent_start").toLocalDateTime();
            LocalDateTime end = rs.getTimestamp("rent_end").toLocalDateTime();
            long hours = ChronoUnit.HOURS.between(start, end);
            if (hours < 1) hours = 1;
            boolean hasDriver = rs.getBoolean("has_driver");
            double total = rs.getDouble("total_price");
            double lateFee = rs.getDouble("late_fee");
            String status = rs.getString("status");
            String returnStr = rs.getTimestamp("actual_return") != null ?
                rs.getTimestamp("actual_return").toLocalDateTime().format(dtfShort) : "-";
            String paymentMethod = rs.getString("payment_method") != null ?
                rs.getString("payment_method") : "Cash on Pickup";
            String paymentStatus = rs.getString("payment_status") != null ?
                rs.getString("payment_status") : "Pending";
            double rentalCharge = hours * priceHr * qty;
            double driverCharge = hasDriver ? hours * DRIVER_RATE_PER_HOUR * qty : 0;
            String dateStr = LocalDateTime.now().format(
                DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            String payColor = paymentStatus.equals("Paid") ? "#a6e3a1" :
                paymentStatus.equals("Failed") ? "#f38ba8" : "#f9e2af";

            String html = "<html><head><style>" +
                "body{font-family:'Segoe UI',sans-serif;background:#1e1e2e;color:#cdd6f4;margin:0;padding:24px;}" +
                ".header{text-align:center;border-bottom:2px solid #89b4fa;padding-bottom:14px;margin-bottom:16px;}" +
                ".company{font-size:28px;font-weight:bold;color:#89b4fa;}" +
                ".tagline{font-size:11px;color:#9399b8;letter-spacing:2px;}" +
                ".receipt-label{font-size:14px;color:#a6e3a1;font-weight:bold;margin:12px 0 8px;}" +
                ".divider{border-top:1px dashed #585b70;margin:10px 0;}" +
                "table.info{width:100%;border-collapse:collapse;}" +
                "table.info td{padding:5px 8px;font-size:13px;}" +
                "table.info .lbl{color:#9399b8;font-weight:bold;width:140px;}" +
                "table.info .val{color:#cdd6f4;}" +
                "table.items{width:100%;border-collapse:collapse;margin:10px 0;}" +
                "table.items th{background:#313244;color:#cdd6f4;padding:8px;text-align:left;font-size:12px;}" +
                "table.items td{padding:8px;border-bottom:1px solid #45475a;font-size:13px;color:#cdd6f4;}" +
                "table.items td.amount{text-align:right;}" +
                ".grand-total{font-size:20px;font-weight:bold;color:#a6e3a1;border-top:2px solid #a6e3a1;padding-top:8px;}" +
                ".pay-box{background:#313244;border:1px solid #89b4fa;padding:10px;border-radius:6px;margin:8px 0;}" +
                ".footer{text-align:center;margin-top:20px;padding-top:14px;border-top:1px dashed #585b70;color:#9399b8;font-size:11px;}" +
                "</style></head><body>" +
                "<div class='header'><div class='company'>ELITE CAR RENTAL</div>" +
                "<div class='tagline'>AFFORDABLE PREMIUM CAR RENTAL SERVICE</div></div>" +
                "<div class='receipt-label'>RECEIPT</div>" +
                "<table class='info'><tr><td class='lbl'>Receipt:</td><td class='val'>"+rId+"</td>" +
                "<td class='lbl'>Date:</td><td class='val'>"+dateStr+"</td></tr></table>" +
                "<div class='divider'></div>" +
                "<div class='receipt-label'>CUSTOMER</div>" +
                "<table class='info'><tr><td class='lbl'>Name:</td><td class='val'>"+custName+"</td>" +
                "<td class='lbl'>Contact:</td><td class='val'>"+custContact+"</td></tr>" +
                "<tr><td class='lbl'>Email:</td><td class='val'>"+custEmail+"</td></tr></table>" +
                "<div class='divider'></div>" +
                "<div class='receipt-label'>VEHICLE</div>" +
                "<table class='info'><tr><td class='lbl'>Vehicle:</td><td class='val'>"+carName+" "+carModel+"</td>" +
                "<td class='lbl'>Rate:</td><td class='val'>Rs. "+String.format("%.0f",priceHr)+"/hr</td></tr>" +
                "<tr><td class='lbl'>Pickup:</td><td class='val'>"+start.format(dtfShort)+"</td>" +
                "<td class='lbl'>Return:</td><td class='val'>"+end.format(dtfShort)+"</td></tr>" +
                "<tr><td class='lbl'>Duration:</td><td class='val'>"+hours+" hrs ("+hours/24+"d "+hours%24+"h)</td>" +
                "<td class='lbl'>Qty:</td><td class='val' style='color:#fab387;font-weight:bold'>"+qty+" car(s)</td></tr>" +
                "<tr><td class='lbl'>Driver:</td><td class='val'>"+(hasDriver?"Yes (+Rs."+DRIVER_RATE_PER_HOUR+"/hr)":"No")+"</td></tr></table>" +
                "<div class='divider'></div>" +
                "<div class='receipt-label'>PAYMENT</div>" +
                "<div class='pay-box'><table class='info'>" +
                "<tr><td class='lbl'>Method:</td><td class='val' style='color:#89b4fa;font-weight:bold'>"+paymentMethod+"</td></tr>" +
                "<tr><td class='lbl'>Status:</td><td class='val' style='color:"+payColor+";font-weight:bold'>"+paymentStatus+"</td></tr>" +
                "</table></div>" +
                "<div class='divider'></div>" +
                "<div class='receipt-label'>CHARGES</div>" +
                "<table class='items'><tr><th>Description</th><th>Details</th><th style='text-align:right'>Amount</th></tr>" +
                "<tr><td>Rental</td><td>"+qty+" x "+hours+" hrs x Rs."+String.format("%.0f",priceHr)+"</td>" +
                "<td class='amount'>Rs. "+String.format("%,.2f",rentalCharge)+"</td></tr>";
            if (hasDriver) html += "<tr><td>Driver</td><td>"+qty+" x "+hours+" hrs x Rs."+DRIVER_RATE_PER_HOUR+"</td>" +
                "<td class='amount'>Rs. "+String.format("%,.2f",driverCharge)+"</td></tr>";
            if (lateFee > 0) html += "<tr><td style='color:#f38ba8'>Late Fee (1.5x)</td><td></td>" +
                "<td class='amount' style='color:#f38ba8'>Rs. "+String.format("%,.2f",lateFee)+"</td></tr>";
            html += "</table><div style='text-align:right;margin-top:12px'><table style='margin-left:auto'>" +
                "<tr class='grand-total'><td>TOTAL:</td>" +
                "<td style='text-align:right;padding-left:20px'>Rs. "+String.format("%,.2f",total+lateFee)+"</td></tr></table></div>" +
                "<div class='divider'></div>" +
                "<table class='info'><tr><td class='lbl'>Status:</td><td class='val'>"+status+"</td>" +
                "<td class='lbl'>Returned:</td><td class='val'>"+returnStr+"</td></tr></table>" +
                "<div class='footer'>Thank you! Drive Safe - Elite Car Rental</div></body></html>";

            JDialog dlg = new JDialog(this, "Receipt - "+rId, false);
            dlg.setSize(540, 820); dlg.setLocationRelativeTo(this);
            JEditorPane ep = new JEditorPane("text/html", html); ep.setEditable(false);
            JScrollPane sp = new JScrollPane(ep);
            JButton printBtn = styledBtn("PRINT", blue), closeBtn = styledBtn("CLOSE", textSub);
            JPanel btnP = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 8));
            btnP.setBackground(bgSurface); btnP.add(printBtn); btnP.add(closeBtn);
            dlg.add(sp, BorderLayout.CENTER); dlg.add(btnP, BorderLayout.SOUTH);
            printBtn.addActionListener(ev -> { try { ep.print(); } catch(PrinterException ex){} });
            closeBtn.addActionListener(ev -> dlg.dispose());
            dlg.setVisible(true);
        } catch(Exception e) { e.printStackTrace(); }
    }

    // ========================================================================
    //  LOGIN + FORGOT PASSWORD
    // ========================================================================
    JPanel makeLoginPanel() {
        JPanel outer = new JPanel(new GridBagLayout()); outer.setBackground(bgBase);
        JPanel cp = new JPanel(); cp.setLayout(new BoxLayout(cp,BoxLayout.Y_AXIS));
        cp.setBackground(bgSurface);
        cp.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(60,60,90),1),
            BorderFactory.createEmptyBorder(40,55,40,55)));
        JLabel title = new JLabel("ELITE CAR RENTAL", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI",Font.BOLD,28)); title.setForeground(blue);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel sub = new JLabel("Affordable Premium Car Rental", SwingConstants.CENTER);
        sub.setFont(new Font("Segoe UI",Font.PLAIN,13)); sub.setForeground(textSub);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel priceBanner = new JLabel("Budget cars from Rs.50/hr | Driver Rs.50/hr", SwingConstants.CENTER);
        priceBanner.setFont(new Font("Segoe UI",Font.BOLD,12)); priceBanner.setForeground(green);
        priceBanner.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel payBanner = new JLabel("JazzCash | EasyPaisa | Bank | Cash", SwingConstants.CENTER);
        payBanner.setFont(new Font("Segoe UI",Font.PLAIN,11)); payBanner.setForeground(teal);
        payBanner.setAlignmentX(Component.CENTER_ALIGNMENT);
        JPanel form = new JPanel(new GridBagLayout()); form.setBackground(bgSurface);
        GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(8,6,8,6);
        loginUser.setBackground(bgInput); loginUser.setForeground(white);
        loginUser.setCaretColor(white);
        loginUser.setBorder(BorderFactory.createLineBorder(new Color(80,80,110)));
        loginPass.setBackground(bgInput); loginPass.setForeground(white);
        loginPass.setCaretColor(white);
        loginPass.setBorder(BorderFactory.createLineBorder(new Color(80,80,110)));
        g.gridx=0;g.gridy=0;form.add(lbl("Username"),g);g.gridx=1;form.add(loginUser,g);
        g.gridx=0;g.gridy=1;form.add(lbl("Password"),g);g.gridx=1;form.add(loginPass,g);
        JButton loginBtn=styledBtn("LOGIN",blue),signupBtn=styledBtn("SIGN UP",mauve),
            forgotBtn=styledBtn("FORGOT PASSWORD",red);
        forgotBtn.setPreferredSize(new Dimension(180,34));
        g.gridx=0;g.gridy=2;form.add(loginBtn,g);g.gridx=1;form.add(signupBtn,g);
        g.gridx=0;g.gridy=3;g.gridwidth=2;form.add(forgotBtn,g);g.gridwidth=1;
        cp.add(title); cp.add(Box.createVerticalStrut(5)); cp.add(sub);
        cp.add(Box.createVerticalStrut(4)); cp.add(priceBanner);
        cp.add(Box.createVerticalStrut(3)); cp.add(payBanner);
        cp.add(Box.createVerticalStrut(22)); cp.add(form);
        loginBtn.addActionListener(e->doLogin());
        signupBtn.addActionListener(e->card.show(mainPanel,"signup"));
        forgotBtn.addActionListener(e->doForgotPassword());
        outer.add(cp); return outer;
    }

    void doLogin() {
        try { String u = loginUser.getText().trim(), p = String.valueOf(loginPass.getPassword());
            if (u.isEmpty()||p.isEmpty()) { JOptionPane.showMessageDialog(this,"Enter username & password!"); return; }
            PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE username=? AND password=?");
            ps.setString(1,u); ps.setString(2,p); ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                currentUserName = rs.getString("name"); currentUserContact = rs.getString("contact");
                currentUserEmail = rs.getString("email"); currentUserId = rs.getInt("id");
                if ("Admin".equalsIgnoreCase(rs.getString("role"))) { refreshAdmin(); card.show(mainPanel,"admin_page"); }
                else {
                    userTopBarLabel.setText("  ELITE CAR RENTAL - Welcome, "+currentUserName+"!");
                    profileNameVal.setText(currentUserName); profileEmailVal.setText(currentUserEmail);
                    profileContactVal.setText(currentUserContact);
                    refreshUserCars(); refreshUserRentals(); refreshUserHistory();
                    card.show(mainPanel,"user_page");
                }
                loginUser.setText(""); loginPass.setText("");
            } else { JOptionPane.showMessageDialog(this,"Invalid credentials!\nForgot? Click FORGOT PASSWORD."); }
        } catch(Exception e) { e.printStackTrace(); }
    }

    void doForgotPassword() {
        JPanel vp = new JPanel(new GridLayout(2,2,8,8)); vp.setBackground(bgSurface);
        JTextField uf = new JTextField(), cf = new JTextField();
        uf.setBackground(bgInput); uf.setForeground(white);
        cf.setBackground(bgInput); cf.setForeground(white);
        vp.add(lbl("Username:")); vp.add(uf);
        vp.add(lbl("Registered Contact:")); vp.add(cf);
        if (JOptionPane.showConfirmDialog(this,vp,"Forgot Password - Verify",
                JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION) return;
        String username = uf.getText().trim(), contact = cf.getText().trim();
        if (username.isEmpty()||contact.isEmpty()) { JOptionPane.showMessageDialog(this,"Fill both fields!"); return; }
        try { PreparedStatement ps = con.prepareStatement("SELECT id,contact FROM users WHERE username=?");
            ps.setString(1,username); ResultSet rs = ps.executeQuery();
            if (!rs.next()) { JOptionPane.showMessageDialog(this,"Username not found!"); return; }
            if (!rs.getString("contact").equals(contact)) { JOptionPane.showMessageDialog(this,"Contact doesn't match!"); return; }
            int uid = rs.getInt("id");
            JPanel pp = new JPanel(new GridLayout(2,2,8,8)); pp.setBackground(bgSurface);
            JPasswordField np = new JPasswordField(), cp2 = new JPasswordField();
            np.setBackground(bgInput); np.setForeground(white);
            cp2.setBackground(bgInput); cp2.setForeground(white);
            pp.add(lbl("New Password:")); pp.add(np);
            pp.add(lbl("Confirm:")); pp.add(cp2);
            if (JOptionPane.showConfirmDialog(this,pp,"Set New Password",
                    JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION) return;
            String n = String.valueOf(np.getPassword()), c = String.valueOf(cp2.getPassword());
            if (n.length()<8) { JOptionPane.showMessageDialog(this,"Min 8 chars!"); return; }
            if (!n.equals(c)) { JOptionPane.showMessageDialog(this,"Passwords don't match!"); return; }
            PreparedStatement upd = con.prepareStatement("UPDATE users SET password=? WHERE id=?");
            upd.setString(1,n); upd.setInt(2,uid); upd.executeUpdate();
            JOptionPane.showMessageDialog(this,"Password reset! Login now.");
        } catch(Exception e) { JOptionPane.showMessageDialog(this,"Error: "+e.getMessage()); }
    }

    // ========================================================================
    //  SIGNUP
    // ========================================================================
    JPanel makeSignupPanel() {
        JPanel outer = new JPanel(new GridBagLayout()); outer.setBackground(bgBase);
        JPanel cp = new JPanel(); cp.setLayout(new BoxLayout(cp,BoxLayout.Y_AXIS));
        cp.setBackground(bgSurface);
        cp.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(60,60,90),1),
            BorderFactory.createEmptyBorder(20,35,20,35)));
        JLabel title = new JLabel("CREATE ACCOUNT", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI",Font.BOLD,20)); title.setForeground(green);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel sub = new JLabel("Join Elite Car Rental!", SwingConstants.CENTER);
        sub.setFont(new Font("Segoe UI",Font.PLAIN,12)); sub.setForeground(textSub);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);
        JPanel form = new JPanel(new GridBagLayout()); form.setBackground(bgSurface);
        GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(4,4,4,4);
        g.anchor = GridBagConstraints.WEST; g.fill = GridBagConstraints.HORIZONTAL;
        JTextField[] fields = {sName,sContact,sEmail,sUser,sPass};
        for (JTextField f : fields) { f.setBackground(bgInput); f.setForeground(white);
            f.setCaretColor(white); f.setBorder(BorderFactory.createLineBorder(new Color(80,80,110))); }
        JLabel[] msgs = {lblNameMsg,lblContactMsg,lblEmailMsg,lblUserMsg,lblPassMsg};
        for (JLabel m : msgs) { m.setFont(new Font("Segoe UI",Font.PLAIN,10));
            m.setForeground(red); m.setPreferredSize(new Dimension(160,16)); }
        g.gridx=0;g.gridy=0;form.add(lbl("Full Name"),g);g.gridx=1;form.add(sName,g);g.gridx=2;form.add(lblNameMsg,g);
        g.gridx=0;g.gridy=1;form.add(lbl("Contact"),g);g.gridx=1;form.add(sContact,g);g.gridx=2;form.add(lblContactMsg,g);
        g.gridx=0;g.gridy=2;form.add(lbl("Email"),g);g.gridx=1;form.add(sEmail,g);g.gridx=2;form.add(lblEmailMsg,g);
        g.gridx=0;g.gridy=4;form.add(lbl("Username"),g);g.gridx=1;form.add(sUser,g);g.gridx=2;form.add(lblUserMsg,g);
        g.gridx=0;g.gridy=5;form.add(lbl("Password"),g);g.gridx=1;form.add(sPass,g);g.gridx=2;form.add(lblPassMsg,g);
        showPassCheck.setBackground(bgSurface); showPassCheck.setForeground(textSub);
        g.gridx=1;g.gridy=6;form.add(showPassCheck,g);
        JButton regBtn = styledBtn("REGISTER",green), backBtn = styledBtn("BACK",textSub);
        JPanel btnP = new JPanel(new FlowLayout(FlowLayout.CENTER,15,10)); btnP.setBackground(bgSurface);
        btnP.add(regBtn); btnP.add(backBtn);
        cp.add(title); cp.add(Box.createVerticalStrut(4)); cp.add(sub);
        cp.add(Box.createVerticalStrut(12)); cp.add(form); cp.add(btnP);
        showPassCheck.addActionListener(e->sPass.setEchoChar(showPassCheck.isSelected()?(char)0:'\u2022'));
        sName.addKeyListener(new KeyAdapter(){public void keyReleased(KeyEvent e){String n=sName.getText();lblNameMsg.setForeground(red);if(n.isEmpty())lblNameMsg.setText(" ");else if(!n.matches("[a-zA-Z ]+"))lblNameMsg.setText("Letters only!");else if(n.length()<2)lblNameMsg.setText("Min 2");else{lblNameMsg.setForeground(green);lblNameMsg.setText("Valid");}}});
        sContact.addKeyListener(new KeyAdapter(){public void keyReleased(KeyEvent e){String c=sContact.getText();lblContactMsg.setForeground(red);if(c.isEmpty())lblContactMsg.setText(" ");else if(!c.matches("\\d+"))lblContactMsg.setText("Digits only!");else if(c.length()<10)lblContactMsg.setText("Min 10");else{lblContactMsg.setForeground(green);lblContactMsg.setText("Valid");}}});
        sEmail.addKeyListener(new KeyAdapter(){public void keyReleased(KeyEvent e){String em=sEmail.getText();lblEmailMsg.setForeground(red);if(em.isEmpty())lblEmailMsg.setText(" ");else if(!em.contains("@"))lblEmailMsg.setText("Invalid!");else{lblEmailMsg.setForeground(green);lblEmailMsg.setText("Valid");}}});
        sUser.addKeyListener(new KeyAdapter(){public void keyReleased(KeyEvent e){String u=sUser.getText();lblUserMsg.setForeground(red);if(u.isEmpty()){lblUserMsg.setText(" ");return;}if(u.contains(" "))lblUserMsg.setText("No spaces!");else if(u.length()<3)lblUserMsg.setText("Min 3");else{try{PreparedStatement ps=con.prepareStatement("SELECT username FROM users WHERE username=?");ps.setString(1,u);ResultSet rs=ps.executeQuery();if(rs.next()){lblUserMsg.setForeground(yellow);lblUserMsg.setText("Taken!");}else{lblUserMsg.setForeground(green);lblUserMsg.setText("Available");}}catch(Exception ex){}}}});
        sPass.addKeyListener(new KeyAdapter(){public void keyReleased(KeyEvent e){String p=String.valueOf(sPass.getPassword());lblPassMsg.setForeground(red);if(p.isEmpty())lblPassMsg.setText(" ");else{int s=0;if(p.length()>=8)s++;if(p.matches(".*[A-Z].*"))s++;if(p.matches(".*[a-z].*"))s++;if(p.matches(".*\\d.*"))s++;if(p.matches(".*[!@#$%^&*()].*"))s++;if(s<3){lblPassMsg.setForeground(red);lblPassMsg.setText("Weak");}else if(s<5){lblPassMsg.setForeground(yellow);lblPassMsg.setText("Medium");}else{lblPassMsg.setForeground(green);lblPassMsg.setText("Strong");}}}});
        regBtn.addActionListener(e->doRegister());
        backBtn.addActionListener(e->{clearSignupFields();card.show(mainPanel,"login");});
        outer.add(cp); return outer;
    }
    void clearSignupFields() { sName.setText("");sEmail.setText("");sUser.setText("");sContact.setText("");sPass.setText("");showPassCheck.setSelected(false);sPass.setEchoChar('\u2022');lblNameMsg.setText(" ");lblEmailMsg.setText(" ");lblUserMsg.setText(" ");lblPassMsg.setText(" ");lblContactMsg.setText(" "); }
    boolean validateSignup() { boolean ok=true;if(sName.getText().isEmpty()||!sName.getText().matches("[a-zA-Z ]+")||sName.getText().length()<2)ok=false;if(sContact.getText().isEmpty()||!sContact.getText().matches("\\d+")||sContact.getText().length()<10)ok=false;if(sEmail.getText().isEmpty()||!sEmail.getText().contains("@"))ok=false;if(sUser.getText().isEmpty()||sUser.getText().contains(" ")||sUser.getText().length()<3)ok=false;if(String.valueOf(sPass.getPassword()).length()<8)ok=false;return ok; }
    void doRegister() { if(!validateSignup()){JOptionPane.showMessageDialog(this,"Fix all fields!");return;}try{String email=sEmail.getText();if(!email.contains("@"))email=sName.getText().toLowerCase().replace(" ","")+"@eliterental.com";PreparedStatement chk=con.prepareStatement("SELECT username FROM users WHERE username=?");chk.setString(1,sUser.getText());ResultSet rs=chk.executeQuery();if(rs.next()){lblUserMsg.setForeground(red);lblUserMsg.setText("Taken!");return;}PreparedStatement ps=con.prepareStatement("INSERT INTO users(name,email,username,password,role,contact) VALUES(?,?,?,?,'Customer',?)");ps.setString(1,sName.getText());ps.setString(2,email);ps.setString(3,sUser.getText());ps.setString(4,String.valueOf(sPass.getPassword()));ps.setString(5,sContact.getText());ps.executeUpdate();JOptionPane.showMessageDialog(this,"Account created! Login now.");clearSignupFields();card.show(mainPanel,"login");}catch(Exception ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}}

    // ========================================================================
    //  ADMIN PANEL
    // ========================================================================
    JPanel makeAdminPanel() {
        JPanel panel = new JPanel(new BorderLayout()); panel.setBackground(bgBase);
        JPanel topBar = new JPanel(new BorderLayout()); topBar.setBackground(bgOverlay);
        topBar.setPreferredSize(new Dimension(0,48));
        JLabel t = new JLabel("  ADMIN DASHBOARD");
        t.setFont(new Font("Segoe UI",Font.BOLD,16)); t.setForeground(blue);
        topBar.add(t,BorderLayout.WEST);
        JButton logoutBtn = styledBtn("LOGOUT",red); logoutBtn.setPreferredSize(new Dimension(100,30));
        topBar.add(logoutBtn,BorderLayout.EAST);
        logoutBtn.addActionListener(e->card.show(mainPanel,"login"));
        JTabbedPane tabs = new JTabbedPane(); styleTabbedPane(tabs);
        tabs.addTab(" Dashboard ",makeAdminDashboardTab());
        tabs.addTab(" Cars ",makeAdminCarsTab());
        tabs.addTab(" Rentals ",makeAdminRentalsTab());
        tabs.addTab(" Users ",makeAdminUsersTab());
        tabs.addTab(" History ",makeAdminHistoryTab());
        panel.add(topBar,BorderLayout.NORTH); panel.add(tabs,BorderLayout.CENTER); return panel;
    }

    JPanel makeAdminDashboardTab() {
        JPanel p = new JPanel(new BorderLayout(10,10)); p.setBackground(bgBase);
        p.setBorder(BorderFactory.createEmptyBorder(15,15,15,15));
        JPanel statsRow = new JPanel(new GridLayout(1,4,12,0)); statsRow.setBackground(bgBase);
        statsRow.add(statsCard("Cars",dashValCars,"Total Cars",blue));
        statsRow.add(statsCard("Avail",dashValAvail,"Available Cars",green));
        statsRow.add(statsCard("Rent",dashValActive,"Active Rentals",yellow));
        statsRow.add(statsCard("Rev",dashValRevenue,"Total Revenue",peach));
        JPanel recentP = new JPanel(new BorderLayout(6,6)); recentP.setBackground(bgSurface);
        recentP.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(60,60,90)),"Recent Rentals",
            TitledBorder.LEFT,TitledBorder.TOP,new Font("Segoe UI",Font.BOLD,12),blue));
        dashRecentTable = new JTable(dashRecentModel); styleTable(dashRecentTable);
        dashRecentTable.getColumnModel().getColumn(6).setCellRenderer(new StatusRenderer());
        dashRecentTable.getColumnModel().getColumn(5).setCellRenderer(new PaymentMethodRenderer());
        JScrollPane sp = new JScrollPane(dashRecentTable); sp.getViewport().setBackground(bgSurface);
        recentP.add(sp,BorderLayout.CENTER);
        p.add(statsRow,BorderLayout.NORTH); p.add(recentP,BorderLayout.CENTER); return p;
    }

    JPanel makeAdminCarsTab() {
        JPanel p = new JPanel(new BorderLayout(8,8)); p.setBackground(bgBase);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JPanel form = new JPanel(new GridBagLayout()); form.setBackground(bgSurface);
        form.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(60,60,90)),
            "Add / Update Car (Min 1hr, Max 15 days)",
            TitledBorder.LEFT,TitledBorder.TOP,new Font("Segoe UI",Font.BOLD,12),blue));
        GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(4,6,4,6);
        g.anchor = GridBagConstraints.WEST;
        JTextField cBrand=new JTextField(12);cBrand.setBackground(bgInput);cBrand.setForeground(white);cBrand.setCaretColor(white);
        JTextField cModel=new JTextField(12);cModel.setBackground(bgInput);cModel.setForeground(white);cModel.setCaretColor(white);
        JTextField cPrice=new JTextField(8);cPrice.setBackground(bgInput);cPrice.setForeground(white);cPrice.setCaretColor(white);
        JTextField cMinH=new JTextField(5);cMinH.setBackground(bgInput);cMinH.setForeground(white);cMinH.setCaretColor(white);
        JTextField cMaxH=new JTextField(5);cMaxH.setBackground(bgInput);cMaxH.setForeground(white);cMaxH.setCaretColor(white);
        JTextField cQty=new JTextField(5);cQty.setBackground(bgInput);cQty.setForeground(white);cQty.setCaretColor(white);
        JTextField cImg=new JTextField(20);cImg.setBackground(bgInput);cImg.setForeground(white);cImg.setCaretColor(white);
        JLabel editIdLabel = new JLabel(""); editIdLabel.setForeground(yellow);
        g.gridx=0;g.gridy=0;form.add(lbl("Brand"),g);g.gridx=1;form.add(cBrand,g);g.gridx=2;form.add(lbl("Model"),g);g.gridx=3;form.add(cModel,g);
        g.gridx=0;g.gridy=1;form.add(lbl("Rs/Hour"),g);g.gridx=1;form.add(cPrice,g);g.gridx=2;form.add(lbl("Min Hrs"),g);g.gridx=3;form.add(cMinH,g);
        g.gridx=0;g.gridy=2;form.add(lbl("Max Hrs"),g);g.gridx=1;form.add(cMaxH,g);g.gridx=2;form.add(lbl("Total Qty"),g);g.gridx=3;form.add(cQty,g);
        g.gridx=0;g.gridy=3;form.add(lbl("Image"),g);g.gridx=1;g.gridwidth=3;form.add(cImg,g);g.gridwidth=1;
        g.gridx=0;g.gridy=4;form.add(lbl("Editing:"),g);g.gridx=1;g.gridwidth=3;form.add(editIdLabel,g);g.gridwidth=1;
        JButton addBtn=styledBtn("ADD",green),updateBtn=styledBtn("UPDATE",blue),clearBtn=styledBtn("CLEAR",textSub),delBtn=styledBtn("DELETE",red),browseBtn=styledBtn("BROWSE",mauve);
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT,8,4)); btnRow.setBackground(bgSurface);
        btnRow.add(addBtn);btnRow.add(updateBtn);btnRow.add(delBtn);btnRow.add(clearBtn);btnRow.add(browseBtn);
        g.gridx=0;g.gridy=5;g.gridwidth=4;form.add(btnRow,g);g.gridwidth=1;
        adminCarTable = new JTable(adminCarModel); styleTable(adminCarTable);
        adminCarTable.getColumnModel().getColumn(8).setCellRenderer(new ImageRenderer());
        adminCarTable.removeColumn(adminCarTable.getColumnModel().getColumn(0));
        setupCarImageTable(adminCarTable, 7); 
        adminCarTable.getColumnModel().getColumn(0).setPreferredWidth(100);
        adminCarTable.getColumnModel().getColumn(1).setPreferredWidth(100);
        adminCarTable.getColumnModel().getColumn(2).setPreferredWidth(70);
        adminCarTable.getColumnModel().getColumn(3).setPreferredWidth(50);
        adminCarTable.getColumnModel().getColumn(4).setPreferredWidth(50);
        adminCarTable.getColumnModel().getColumn(5).setPreferredWidth(50);
        adminCarTable.getColumnModel().getColumn(6).setPreferredWidth(50);
        JScrollPane sp = new JScrollPane(adminCarTable); sp.getViewport().setBackground(bgSurface);
        p.add(form,BorderLayout.NORTH); p.add(sp,BorderLayout.CENTER);
        adminCarTable.addMouseListener(new MouseAdapter(){public void mouseClicked(MouseEvent e){int row=adminCarTable.getSelectedRow();int hiddenId=Integer.parseInt(adminCarModel.getValueAt(adminCarTable.convertRowIndexToModel(row),0).toString());editIdLabel.setText("Car ID: "+hiddenId);cBrand.setText(adminCarTable.getValueAt(row,0).toString());cModel.setText(adminCarTable.getValueAt(row,1).toString());cPrice.setText(adminCarTable.getValueAt(row,2).toString());cMinH.setText(adminCarTable.getValueAt(row,3).toString());cMaxH.setText(adminCarTable.getValueAt(row,4).toString());cQty.setText(adminCarModel.getValueAt(adminCarTable.convertRowIndexToModel(row),6).toString());cImg.setText(adminCarTable.getValueAt(row,7).toString());}});
        addBtn.addActionListener(e->{try{if(cBrand.getText().isEmpty()||cModel.getText().isEmpty()||cPrice.getText().isEmpty()){JOptionPane.showMessageDialog(this,"Required!");return;}int minH=cMinH.getText().isEmpty()?DEFAULT_MIN_HOURS:Integer.parseInt(cMinH.getText());int maxH=cMaxH.getText().isEmpty()?DEFAULT_MAX_HOURS:Integer.parseInt(cMaxH.getText());if(minH<1)minH=1;if(maxH<minH){JOptionPane.showMessageDialog(this,"Max>=Min!");return;}PreparedStatement ps=con.prepareStatement("INSERT INTO cars(name,model,price_per_hour,min_hours,max_hours,total_qty,available_qty,img_path) VALUES(?,?,?,?,?,?,?,?)");ps.setString(1,cBrand.getText());ps.setString(2,cModel.getText());ps.setDouble(3,Double.parseDouble(cPrice.getText()));ps.setInt(4,minH);ps.setInt(5,maxH);int qty=cQty.getText().isEmpty()?1:Integer.parseInt(cQty.getText());ps.setInt(6,qty);ps.setInt(7,qty);String imgPath=cImg.getText();if(!imgPath.isEmpty())imgPath=resolveImage(imgPath);ps.setString(8,imgPath);ps.executeUpdate();refreshAdminCars();clearCarForm(cBrand,cModel,cPrice,cMinH,cMaxH,cQty,cImg,editIdLabel);JOptionPane.showMessageDialog(this,"Added!");}catch(Exception ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}});
        updateBtn.addActionListener(e->{if(editIdLabel.getText().isEmpty()){JOptionPane.showMessageDialog(this,"Select first!");return;}try{int id=Integer.parseInt(editIdLabel.getText().replace("Car ID: ",""));int minH=cMinH.getText().isEmpty()?DEFAULT_MIN_HOURS:Integer.parseInt(cMinH.getText());int maxH=cMaxH.getText().isEmpty()?DEFAULT_MAX_HOURS:Integer.parseInt(cMaxH.getText());PreparedStatement ps=con.prepareStatement("UPDATE cars SET name=?,model=?,price_per_hour=?,min_hours=?,max_hours=?,total_qty=?,available_qty=?,img_path=? WHERE id=?");ps.setString(1,cBrand.getText());ps.setString(2,cModel.getText());ps.setDouble(3,Double.parseDouble(cPrice.getText()));ps.setInt(4,minH);ps.setInt(5,maxH);int newTotal=cQty.getText().isEmpty()?1:Integer.parseInt(cQty.getText());ps.setInt(6,newTotal);PreparedStatement rented=con.prepareStatement("SELECT COALESCE(SUM(quantity),0) FROM rentals WHERE car_id=? AND status='Active'");rented.setInt(1,id);ResultSet rs=rented.executeQuery();rs.next();ps.setInt(7,Math.max(0,newTotal-rs.getInt(1)));ps.setString(8,cImg.getText());ps.setInt(9,id);ps.executeUpdate();refreshAdminCars();clearCarForm(cBrand,cModel,cPrice,cMinH,cMaxH,cQty,cImg,editIdLabel);JOptionPane.showMessageDialog(this,"Updated!");}catch(Exception ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}});
        delBtn.addActionListener(e->{if(editIdLabel.getText().isEmpty()){JOptionPane.showMessageDialog(this,"Select first!");return;}if(JOptionPane.showConfirmDialog(this,"Delete?","Confirm",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;try{int id=Integer.parseInt(editIdLabel.getText().replace("Car ID: ",""));con.prepareStatement("DELETE FROM cars WHERE id="+id).executeUpdate();refreshAdminCars();clearCarForm(cBrand,cModel,cPrice,cMinH,cMaxH,cQty,cImg,editIdLabel);}catch(Exception ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}});
        clearBtn.addActionListener(e->clearCarForm(cBrand,cModel,cPrice,cMinH,cMaxH,cQty,cImg,editIdLabel));
        browseBtn.addActionListener(e->{JFileChooser fc=new JFileChooser();if(fc.showOpenDialog(this)==JFileChooser.APPROVE_OPTION)cImg.setText(fc.getSelectedFile().getAbsolutePath());});
        return p;
    }
    void clearCarForm(JTextField b,JTextField m,JTextField pr,JTextField mh,JTextField mx,JTextField q,JTextField img,JLabel id){b.setText("");m.setText("");pr.setText("");mh.setText("");mx.setText("");q.setText("");img.setText("");id.setText("");}

    JPanel makeAdminRentalsTab() {
        JPanel p = new JPanel(new BorderLayout(8,8)); p.setBackground(bgBase);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT,10,4)); btnPanel.setBackground(bgBase);
        JButton refreshBtn=styledBtn("REFRESH",blue),returnBtn=styledBtn("RETURN",green),
            cancelBtn=styledBtn("CANCEL",red),lateBtn=styledBtn("LATE FEE",yellow),
            receiptBtn=styledBtn("RECEIPT",mauve),payStatusBtn=styledBtn("PAY STATUS",teal);
        btnPanel.add(refreshBtn);btnPanel.add(returnBtn);btnPanel.add(cancelBtn);
        btnPanel.add(lateBtn);btnPanel.add(receiptBtn);btnPanel.add(payStatusBtn);
        adminRentalTable = new JTable(adminRentalModel); styleTable(adminRentalTable);
        adminRentalTable.getColumnModel().getColumn(12).setCellRenderer(new StatusRenderer());
        adminRentalTable.getColumnModel().getColumn(10).setCellRenderer(new PaymentMethodRenderer());
        adminRentalTable.getColumnModel().getColumn(11).setCellRenderer(new PayStatusRenderer());
        for(int hc:new int[]{13,14}){adminRentalTable.getColumnModel().getColumn(hc).setMinWidth(0);adminRentalTable.getColumnModel().getColumn(hc).setMaxWidth(0);adminRentalTable.getColumnModel().getColumn(hc).setPreferredWidth(0);}
        JScrollPane sp = new JScrollPane(adminRentalTable); sp.getViewport().setBackground(bgSurface);
        p.add(btnPanel,BorderLayout.NORTH); p.add(sp,BorderLayout.CENTER);
        refreshBtn.addActionListener(e->refreshAdminRentals());
        returnBtn.addActionListener(e->{int row=adminRentalTable.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select!");return;}int mr=adminRentalTable.convertRowIndexToModel(row);if(!"Active".equals(adminRentalModel.getValueAt(mr,12).toString())){JOptionPane.showMessageDialog(this,"Only active!");return;}doReturnCar(Integer.parseInt(adminRentalModel.getValueAt(mr,0).toString()),Integer.parseInt(adminRentalModel.getValueAt(mr,13).toString()));});
        cancelBtn.addActionListener(e->{int row=adminRentalTable.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select!");return;}int mr=adminRentalTable.convertRowIndexToModel(row);if(!"Active".equals(adminRentalModel.getValueAt(mr,12).toString())){JOptionPane.showMessageDialog(this,"Only active!");return;}int rid=Integer.parseInt(adminRentalModel.getValueAt(mr,0).toString()),cid=Integer.parseInt(adminRentalModel.getValueAt(mr,13).toString()),qty=Integer.parseInt(adminRentalModel.getValueAt(mr,7).toString());if(JOptionPane.showConfirmDialog(this,"Cancel #"+rid+"?","Confirm",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;try{con.prepareStatement("UPDATE rentals SET status='Cancelled',actual_return=NOW() WHERE id="+rid).executeUpdate();con.prepareStatement("UPDATE cars SET available_qty=available_qty+"+qty+" WHERE id="+cid).executeUpdate();refreshAdminRentals();refreshAdminCars();refreshAdminHistory();refreshDashboard();JOptionPane.showMessageDialog(this,"Cancelled!");}catch(Exception ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}});
        lateBtn.addActionListener(e->{int row=adminRentalTable.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select!");return;}int mr=adminRentalTable.convertRowIndexToModel(row);int rid=Integer.parseInt(adminRentalModel.getValueAt(mr,0).toString());try{PreparedStatement ps=con.prepareStatement("SELECT r.rent_end,c.price_per_hour,r.quantity FROM rentals r JOIN cars c ON r.car_id=c.id WHERE r.id=?");ps.setInt(1,rid);ResultSet rs=ps.executeQuery();if(rs.next()){LocalDateTime end=rs.getTimestamp("rent_end").toLocalDateTime();if(LocalDateTime.now().isAfter(end)){long hrs=ChronoUnit.HOURS.between(end,LocalDateTime.now());JOptionPane.showMessageDialog(this,String.format("Late %d hrs x %d car(s)\nFee: Rs. %.2f",hrs,rs.getInt("quantity"),hrs*rs.getDouble("price_per_hour")*rs.getInt("quantity")*1.5));}else JOptionPane.showMessageDialog(this,"Not overdue.");}}catch(Exception ex){}});
        receiptBtn.addActionListener(e->{int row=adminRentalTable.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select!");return;}showReceipt(Integer.parseInt(adminRentalModel.getValueAt(adminRentalTable.convertRowIndexToModel(row),0).toString()));});
        payStatusBtn.addActionListener(e->{int row=adminRentalTable.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select a rental!");return;}int mr=adminRentalTable.convertRowIndexToModel(row);int rid=Integer.parseInt(adminRentalModel.getValueAt(mr,0).toString());String curPayStatus=adminRentalModel.getValueAt(mr,11).toString();showPaymentStatusDialog(rid,curPayStatus);});
        return p;
    }

    JPanel makeAdminUsersTab() {
        JPanel p = new JPanel(new BorderLayout(8,8)); p.setBackground(bgBase);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JPanel topRow = new JPanel(new FlowLayout(FlowLayout.LEFT,10,4)); topRow.setBackground(bgBase);
        JButton refreshBtn = styledBtn("REFRESH",blue); topRow.add(refreshBtn); topRow.add(lbl("Filter:"));
        adminUserCombo = new JComboBox<>(); adminUserCombo.setBackground(bgInput);
        adminUserCombo.setForeground(white); adminUserCombo.setPreferredSize(new Dimension(160,30));
        topRow.add(adminUserCombo);
        adminUserTable = new JTable(adminUserModel); styleTable(adminUserTable);
        JScrollPane sp = new JScrollPane(adminUserTable); sp.getViewport().setBackground(bgSurface);
        p.add(topRow,BorderLayout.NORTH); p.add(sp,BorderLayout.CENTER);
        refreshBtn.addActionListener(e->{refreshAdminUsers();populateUserCombo();});
        adminUserCombo.addActionListener(e->{String sel=(String)adminUserCombo.getSelectedItem();if(sel!=null&&!sel.equals("-- All --"))filterUserTable(sel);else refreshAdminUsers();});
        return p;
    }

    JPanel makeAdminHistoryTab() {
        JPanel p = new JPanel(new BorderLayout(8,8)); p.setBackground(bgBase);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JPanel topRow = new JPanel(new FlowLayout(FlowLayout.LEFT,10,4)); topRow.setBackground(bgBase);
        JButton refreshBtn=styledBtn("REFRESH",blue),receiptBtn=styledBtn("RECEIPT",mauve);
        topRow.add(refreshBtn); topRow.add(receiptBtn);
        adminHistTable = new JTable(adminHistModel); styleTable(adminHistTable);
        adminHistTable.getColumnModel().getColumn(9).setCellRenderer(new StatusRenderer());
        adminHistTable.getColumnModel().getColumn(8).setCellRenderer(new PaymentMethodRenderer());
        JScrollPane sp = new JScrollPane(adminHistTable); sp.getViewport().setBackground(bgSurface);
        p.add(topRow,BorderLayout.NORTH); p.add(sp,BorderLayout.CENTER);
        refreshBtn.addActionListener(e->refreshAdminHistory());
        receiptBtn.addActionListener(e->{int row=adminHistTable.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select!");return;}showReceipt(Integer.parseInt(adminHistModel.getValueAt(adminHistTable.convertRowIndexToModel(row),0).toString()));});
        return p;
    }

    // ========================================================================
    //  USER PANEL
    // ========================================================================
    JPanel makeUserPanel() {
        JPanel panel = new JPanel(new BorderLayout()); panel.setBackground(bgBase);
        JPanel topBar = new JPanel(new BorderLayout()); topBar.setBackground(bgOverlay);
        topBar.setPreferredSize(new Dimension(0,48));
        userTopBarLabel.setFont(new Font("Segoe UI",Font.BOLD,16)); userTopBarLabel.setForeground(blue);
        topBar.add(userTopBarLabel,BorderLayout.WEST);
        JButton logoutBtn = styledBtn("LOGOUT",red); logoutBtn.setPreferredSize(new Dimension(100,30));
        topBar.add(logoutBtn,BorderLayout.EAST);
        logoutBtn.addActionListener(e->card.show(mainPanel,"login"));
        JTabbedPane tabs = new JTabbedPane(); styleTabbedPane(tabs);
        tabs.addTab(" Available Cars ",makeUserCarsTab());
        tabs.addTab(" My Rentals ",makeUserRentalsTab());
        tabs.addTab(" History ",makeUserHistoryTab());
        tabs.addTab(" Profile ",makeUserProfileTab());
        panel.add(topBar,BorderLayout.NORTH); panel.add(tabs,BorderLayout.CENTER); return panel;
    }

    JPanel makeUserCarsTab() {
        JPanel p = new JPanel(new BorderLayout(8,8)); p.setBackground(bgBase);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JPanel form = new JPanel(new GridBagLayout()); form.setBackground(bgSurface);
        form.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(60,60,90)),
            "Rent a Car — Affordable Rates! (Min 1 hr, Max 15 days)",
            TitledBorder.LEFT,TitledBorder.TOP,new Font("Segoe UI",Font.BOLD,12),green));
        GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(4,6,4,6);
        g.anchor = GridBagConstraints.WEST;
        JLabel selCarLabel = new JLabel("No car selected"); selCarLabel.setForeground(yellow);
        selCarLabel.setFont(new Font("Segoe UI",Font.BOLD,12));
        JLabel hourInfoLabel = new JLabel(" "); hourInfoLabel.setForeground(teal);
        hourInfoLabel.setFont(new Font("Segoe UI",Font.PLAIN,11));
        CalendarDatePicker startDatePicker = new CalendarDatePicker(LocalDate.now());
        CalendarDatePicker endDatePicker = new CalendarDatePicker(LocalDate.now());
        SpinnerNumberModel qtyModel = new SpinnerNumberModel(1,1,1,1);
        JSpinner qtySpinner = new JSpinner(qtyModel);
        qtySpinner.setFont(new Font("Segoe UI",Font.BOLD,14));
        qtySpinner.setPreferredSize(new Dimension(60,28));
        ((JSpinner.DefaultEditor)qtySpinner.getEditor()).getTextField().setBackground(bgInput);
        ((JSpinner.DefaultEditor)qtySpinner.getEditor()).getTextField().setForeground(white);
        ((JSpinner.DefaultEditor)qtySpinner.getEditor()).getTextField().setCaretColor(white);
        ((JSpinner.DefaultEditor)qtySpinner.getEditor()).getTextField().setFont(new Font("Segoe UI",Font.BOLD,14));
        ((JSpinner.DefaultEditor)qtySpinner.getEditor()).getTextField().setHorizontalAlignment(JTextField.CENTER);
        JCheckBox driverCheck = new JCheckBox("With Driver (+Rs."+DRIVER_RATE_PER_HOUR+"/hr per car)");
        driverCheck.setBackground(bgSurface); driverCheck.setForeground(textMain);
        driverCheck.setFont(new Font("Segoe UI",Font.PLAIN,12));
        JButton rentBtn = styledBtn("RENT NOW",green), estBtn = styledBtn("ESTIMATE",blue);
        JLabel estLabel = new JLabel(" "); estLabel.setForeground(peach);
        estLabel.setFont(new Font("Segoe UI",Font.BOLD,13));
        g.gridx=0;g.gridy=0;g.gridwidth=4;form.add(selCarLabel,g);g.gridwidth=1;
        g.gridx=0;g.gridy=1;g.gridwidth=4;form.add(hourInfoLabel,g);g.gridwidth=1;
        g.gridx=0;g.gridy=2;form.add(lbl("Start Date"),g);g.gridx=1;g.gridwidth=2;form.add(startDatePicker,g);g.gridwidth=1;
        g.gridx=0;g.gridy=3;form.add(lbl("End Date"),g);g.gridx=1;g.gridwidth=2;form.add(endDatePicker,g);g.gridwidth=1;
        g.gridx=0;g.gridy=4;form.add(lbl("Qty:"),g);g.gridx=1;form.add(qtySpinner,g);g.gridx=2;g.gridwidth=2;form.add(driverCheck,g);g.gridwidth=1;
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT,10,4)); btnRow.setBackground(bgSurface);
        btnRow.add(rentBtn); btnRow.add(estBtn); btnRow.add(estLabel);
        g.gridx=0;g.gridy=5;g.gridwidth=4;form.add(btnRow,g);g.gridwidth=1;
        userCarTable = new JTable(customerAvailModel); styleTable(userCarTable);
        userCarTable.getColumnModel().getColumn(5).setCellRenderer(new ImageRenderer());
        userCarTable.getColumnModel().getColumn(0).setMinWidth(0);
        userCarTable.getColumnModel().getColumn(0).setMaxWidth(0);
        userCarTable.getColumnModel().getColumn(0).setPreferredWidth(0);
        setupCarImageTable(userCarTable, 5);
        userCarTable.getColumnModel().getColumn(1).setPreferredWidth(120);
        userCarTable.getColumnModel().getColumn(2).setPreferredWidth(100);
        userCarTable.getColumnModel().getColumn(3).setPreferredWidth(70);
        userCarTable.getColumnModel().getColumn(4).setPreferredWidth(50);
        JScrollPane sp = new JScrollPane(userCarTable); sp.getViewport().setBackground(bgSurface);
        p.add(form,BorderLayout.NORTH); p.add(sp,BorderLayout.CENTER);
        final int[] selectedCarId = {0};
        final int[] carMinHours = {DEFAULT_MIN_HOURS};
        final int[] carMaxHours = {DEFAULT_MAX_HOURS};
        userCarTable.addMouseListener(new MouseAdapter(){public void mouseClicked(MouseEvent e){int row=userCarTable.getSelectedRow();int mr=userCarTable.convertRowIndexToModel(row);selectedCarId[0]=Integer.parseInt(customerAvailModel.getValueAt(mr,0).toString());String brand=userCarTable.getValueAt(row,1).toString(),model=userCarTable.getValueAt(row,2).toString();double price=Double.parseDouble(userCarTable.getValueAt(row,3).toString());int avail=Integer.parseInt(userCarTable.getValueAt(row,4).toString());selCarLabel.setText("Selected: "+brand+" "+model+" @ Rs."+String.format("%.0f",price)+"/hr");qtyModel.setMaximum(avail);qtyModel.setValue(Math.min((Integer)qtyModel.getValue(),avail));try{PreparedStatement ps=con.prepareStatement("SELECT min_hours,max_hours FROM cars WHERE id=?");ps.setInt(1,selectedCarId[0]);ResultSet rs=ps.executeQuery();if(rs.next()){carMinHours[0]=rs.getInt("min_hours");carMaxHours[0]=rs.getInt("max_hours");int maxDays=carMaxHours[0]/24;double dailyRate=price*24;hourInfoLabel.setText("Min: "+carMinHours[0]+" hr(s) | Max: "+maxDays+" days | Daily: Rs."+String.format("%.0f",dailyRate)+" | Avail: "+avail);}}catch(Exception ex){}}});
        estBtn.addActionListener(e->{if(selectedCarId[0]==0){JOptionPane.showMessageDialog(this,"Select a car!");return;}LocalDate startDate=startDatePicker.getSelectedDate(),endDate=endDatePicker.getSelectedDate();if(startDate==null||endDate==null){estLabel.setText("Select dates!");estLabel.setForeground(red);return;}LocalDateTime startDT=startDate.atTime(LocalDateTime.now().getHour(),LocalDateTime.now().getMinute());LocalDateTime endDT=endDate.atTime(23,59);if(startDT.isBefore(LocalDateTime.now())){estLabel.setText("Past time!");estLabel.setForeground(red);return;}long hrs=ChronoUnit.HOURS.between(startDT,endDT);if(hrs<1)hrs=1;if(hrs<carMinHours[0]){estLabel.setForeground(red);estLabel.setText("Min "+carMinHours[0]+" hr(s)!");return;}if(hrs>carMaxHours[0]){estLabel.setForeground(red);estLabel.setText("Max "+(carMaxHours[0]/24)+" days!");return;}int qty=(Integer)qtyModel.getValue();double pph=getCarPrice(selectedCarId[0]);double total=hrs*pph*qty;if(driverCheck.isSelected())total+=hrs*DRIVER_RATE_PER_HOUR*qty;estLabel.setForeground(peach);long days=hrs/24,remHrs=hrs%24;String durStr=days>0?days+"d "+remHrs+"h":hrs+"h";estLabel.setText(String.format("%d car(s) x %s x Rs.%.0f = Rs.%,.0f",qty,durStr,pph,total));});

        rentBtn.addActionListener(e->{
            if(selectedCarId[0]==0){JOptionPane.showMessageDialog(this,"Select a car!");return;}
            LocalDate startDate=startDatePicker.getSelectedDate(),endDate=endDatePicker.getSelectedDate();
            if(startDate==null||endDate==null){JOptionPane.showMessageDialog(this,"Select both dates!");return;}
            LocalDateTime startDT;if(startDate.equals(LocalDate.now())){startDT=LocalDateTime.now();}else{startDT=startDate.atTime(0,0);}
            LocalDateTime endDT=endDate.atTime(23,59);
            if(!endDT.isAfter(startDT)){JOptionPane.showMessageDialog(this,"End date must be after start!");return;}
            long hours=ChronoUnit.HOURS.between(startDT,endDT);if(hours<1)hours=1;
            int qty=(Integer)qtyModel.getValue();
            if(hours<carMinHours[0]){JOptionPane.showMessageDialog(this,"Minimum "+carMinHours[0]+" hour(s) required!");return;}
            if(hours>carMaxHours[0]){JOptionPane.showMessageDialog(this,"Maximum "+(carMaxHours[0]/24)+" days allowed!");return;}
            try{PreparedStatement ps=con.prepareStatement("SELECT available_qty FROM cars WHERE id=?");ps.setInt(1,selectedCarId[0]);ResultSet rs=ps.executeQuery();if(rs.next()&&rs.getInt("available_qty")<qty){JOptionPane.showMessageDialog(this,"Only "+rs.getInt("available_qty")+" available!");return;}}catch(Exception ex){return;}
            double pph=getCarPrice(selectedCarId[0]);
            double total=hours*pph*qty;if(driverCheck.isSelected())total+=hours*DRIVER_RATE_PER_HOUR*qty;
            long days=hours/24,remHrs=hours%24;
            String durStr=days>0?days+" day(s) "+remHrs+" hr(s)":hours+" hour(s)";

            String carInfo = userCarTable.getValueAt(userCarTable.getSelectedRow(),1)+" "+
                userCarTable.getValueAt(userCarTable.getSelectedRow(),2);
            PaymentResult payResult = showPaymentDialog(total, carInfo + " | " + durStr);

            if ("Cancelled".equals(payResult.status)) {
                JOptionPane.showMessageDialog(this, "Rental cancelled - payment not completed.");
                return;
            }
            if ("Failed".equals(payResult.status)) {
                JOptionPane.showMessageDialog(this, "Payment failed! Please try again.");
                return;
            }

            try{PreparedStatement ps=con.prepareStatement("INSERT INTO rentals(car_id,user_id,customer_name,contact,rent_start,rent_end,total_price,has_driver,quantity,payment_method,payment_status) VALUES(?,?,?,?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);ps.setInt(1,selectedCarId[0]);ps.setInt(2,currentUserId);ps.setString(3,currentUserName);ps.setString(4,currentUserContact);ps.setTimestamp(5,Timestamp.valueOf(startDT));ps.setTimestamp(6,Timestamp.valueOf(endDT));ps.setDouble(7,total);ps.setBoolean(8,driverCheck.isSelected());ps.setInt(9,qty);ps.setString(10,payResult.method);ps.setString(11,payResult.status);ps.executeUpdate();ResultSet gk=ps.getGeneratedKeys();int newRid=0;if(gk.next())newRid=gk.getInt(1);con.prepareStatement("UPDATE cars SET available_qty=available_qty-"+qty+" WHERE id="+selectedCarId[0]+" AND available_qty>="+qty).executeUpdate();refreshUserCars();refreshUserRentals();selectedCarId[0]=0;selCarLabel.setText("No car selected");hourInfoLabel.setText(" ");estLabel.setText(" ");qtyModel.setValue(1);startDatePicker.clear();endDatePicker.clear();String payMsg="Paid".equals(payResult.status)?"\nPayment: Confirmed via "+payResult.method:"\nPayment: Pending via "+payResult.method+"\n(Awaiting verification)";JOptionPane.showMessageDialog(this,"Car rented successfully!"+payMsg);if(newRid>0)showReceipt(newRid);}catch(Exception ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}}
        );
        return p;
    }

    double getCarPrice(int carId) {
        try { PreparedStatement ps = con.prepareStatement("SELECT price_per_hour FROM cars WHERE id=?");
            ps.setInt(1,carId); ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getDouble(1);
        } catch(Exception e) {} return 0;
    }

    JPanel makeUserRentalsTab() {
        JPanel p = new JPanel(new BorderLayout(8,8)); p.setBackground(bgBase);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT,10,4)); btnPanel.setBackground(bgBase);
        JButton refreshBtn=styledBtn("REFRESH",blue),returnBtn=styledBtn("RETURN CAR",green),
            cancelBtn=styledBtn("CANCEL",red),receiptBtn=styledBtn("RECEIPT",mauve);
        btnPanel.add(refreshBtn);btnPanel.add(returnBtn);btnPanel.add(cancelBtn);btnPanel.add(receiptBtn);
        userRentTable = new JTable(userRentalModel); styleTable(userRentTable);
        userRentTable.getColumnModel().getColumn(8).setCellRenderer(new StatusRenderer());
        userRentTable.getColumnModel().getColumn(7).setCellRenderer(new PaymentMethodRenderer());
        userRentTable.getColumnModel().getColumn(9).setMinWidth(0);
        userRentTable.getColumnModel().getColumn(9).setMaxWidth(0);
        userRentTable.getColumnModel().getColumn(9).setPreferredWidth(0);
        JScrollPane sp = new JScrollPane(userRentTable); sp.getViewport().setBackground(bgSurface);
        p.add(btnPanel,BorderLayout.NORTH); p.add(sp,BorderLayout.CENTER);
        refreshBtn.addActionListener(e->refreshUserRentals());
        returnBtn.addActionListener(e->{int row=userRentTable.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select!");return;}int mr=userRentTable.convertRowIndexToModel(row);if(!"Active".equals(userRentalModel.getValueAt(mr,8).toString())){JOptionPane.showMessageDialog(this,"Only active!");return;}doReturnCar(Integer.parseInt(userRentalModel.getValueAt(mr,0).toString()),Integer.parseInt(userRentalModel.getValueAt(mr,9).toString()));});
        cancelBtn.addActionListener(e->{int row=userRentTable.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select!");return;}int mr=userRentTable.convertRowIndexToModel(row);if(!"Active".equals(userRentalModel.getValueAt(mr,8).toString())){JOptionPane.showMessageDialog(this,"Only active!");return;}int rid=Integer.parseInt(userRentalModel.getValueAt(mr,0).toString()),cid=Integer.parseInt(userRentalModel.getValueAt(mr,9).toString()),qty=Integer.parseInt(userRentalModel.getValueAt(mr,5).toString());if(JOptionPane.showConfirmDialog(this,"Cancel?","Confirm",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;try{con.prepareStatement("UPDATE rentals SET status='Cancelled',actual_return=NOW() WHERE id="+rid).executeUpdate();con.prepareStatement("UPDATE cars SET available_qty=available_qty+"+qty+" WHERE id="+cid).executeUpdate();refreshUserRentals();refreshUserCars();refreshUserHistory();JOptionPane.showMessageDialog(this,"Cancelled!");}catch(Exception ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}});
        receiptBtn.addActionListener(e->{int row=userRentTable.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select!");return;}showReceipt(Integer.parseInt(userRentalModel.getValueAt(userRentTable.convertRowIndexToModel(row),0).toString()));});
        return p;
    }

    JPanel makeUserHistoryTab() {
        JPanel p = new JPanel(new BorderLayout(8,8)); p.setBackground(bgBase);
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JPanel topRow = new JPanel(new FlowLayout(FlowLayout.LEFT,10,4)); topRow.setBackground(bgBase);
        JButton refreshBtn=styledBtn("REFRESH",blue),receiptBtn=styledBtn("RECEIPT",mauve);
        topRow.add(refreshBtn); topRow.add(receiptBtn);
        userHistTable = new JTable(userHistoryModel); styleTable(userHistTable);
        userHistTable.getColumnModel().getColumn(9).setCellRenderer(new StatusRenderer());
        userHistTable.getColumnModel().getColumn(8).setCellRenderer(new PaymentMethodRenderer());
        JScrollPane sp = new JScrollPane(userHistTable); sp.getViewport().setBackground(bgSurface);
        p.add(topRow,BorderLayout.NORTH); p.add(sp,BorderLayout.CENTER);
        refreshBtn.addActionListener(e->refreshUserHistory());
        receiptBtn.addActionListener(e->{int row=userHistTable.getSelectedRow();if(row<0){JOptionPane.showMessageDialog(this,"Select!");return;}String car=userHistTable.getValueAt(row,0).toString(),start=userHistTable.getValueAt(row,1).toString();try{PreparedStatement ps=con.prepareStatement("SELECT r.id FROM rentals r JOIN cars c ON r.car_id=c.id WHERE CONCAT(c.name,' ',c.model)=? AND DATE_FORMAT(r.rent_start,'%Y-%m-%d %H:%i')=? AND r.user_id=?");ps.setString(1,car);ps.setString(2,start);ps.setInt(3,currentUserId);ResultSet rs=ps.executeQuery();if(rs.next())showReceipt(rs.getInt(1));}catch(Exception ex){}});
        return p;
    }

    JPanel makeUserProfileTab() {
        JPanel p = new JPanel(new GridBagLayout()); p.setBackground(bgBase);
        JPanel c = new JPanel(new GridBagLayout()); c.setBackground(bgSurface);
        c.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(60,60,90),1),
            BorderFactory.createEmptyBorder(30,40,30,40)));
        GridBagConstraints g = new GridBagConstraints(); g.insets = new Insets(10,10,10,10);
        g.anchor = GridBagConstraints.WEST;
        JLabel pt = new JLabel("MY PROFILE"); pt.setFont(new Font("Segoe UI",Font.BOLD,18));
        pt.setForeground(mauve); g.gridx=0;g.gridy=0;g.gridwidth=2;c.add(pt,g);g.gridwidth=1;
        g.gridx=0;g.gridy=1;c.add(lbl("Name:"),g);g.gridx=1;profileNameVal.setForeground(white);
        profileNameVal.setFont(new Font("Segoe UI",Font.PLAIN,14));c.add(profileNameVal,g);
        g.gridx=0;g.gridy=2;c.add(lbl("Email:"),g);g.gridx=1;profileEmailVal.setForeground(white);
        profileEmailVal.setFont(new Font("Segoe UI",Font.PLAIN,14));c.add(profileEmailVal,g);
        g.gridx=0;g.gridy=3;c.add(lbl("Contact:"),g);g.gridx=1;profileContactVal.setForeground(white);
        profileContactVal.setFont(new Font("Segoe UI",Font.PLAIN,14));c.add(profileContactVal,g);
        JTextField newEmail=new JTextField(16);newEmail.setBackground(bgInput);newEmail.setForeground(white);newEmail.setCaretColor(white);
        JTextField newContact=new JTextField(16);newContact.setBackground(bgInput);newContact.setForeground(white);newContact.setCaretColor(white);
        g.gridx=0;g.gridy=5;c.add(lbl("New Email:"),g);g.gridx=1;c.add(newEmail,g);
        g.gridx=0;g.gridy=6;c.add(lbl("New Contact:"),g);g.gridx=1;c.add(newContact,g);
        JButton updateBtn=styledBtn("UPDATE",blue),changePassBtn=styledBtn("CHANGE PASSWORD",mauve);
        JPanel btnRow=new JPanel(new FlowLayout(FlowLayout.LEFT,10,4));btnRow.setBackground(bgSurface);
        btnRow.add(updateBtn);btnRow.add(changePassBtn);
        g.gridx=0;g.gridy=7;g.gridwidth=2;c.add(btnRow,g);g.gridwidth=1;
        updateBtn.addActionListener(e->{try{String em=newEmail.getText(),ct=newContact.getText();if(em.isEmpty()&&ct.isEmpty()){JOptionPane.showMessageDialog(this,"Enter value!");return;}if(!em.isEmpty()){PreparedStatement ps=con.prepareStatement("UPDATE users SET email=? WHERE id=?");ps.setString(1,em);ps.setInt(2,currentUserId);ps.executeUpdate();currentUserEmail=em;profileEmailVal.setText(em);}if(!ct.isEmpty()){PreparedStatement ps=con.prepareStatement("UPDATE users SET contact=? WHERE id=?");ps.setString(1,ct);ps.setInt(2,currentUserId);ps.executeUpdate();currentUserContact=ct;profileContactVal.setText(ct);}newEmail.setText("");newContact.setText("");JOptionPane.showMessageDialog(this,"Updated!");}catch(Exception ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}});
        changePassBtn.addActionListener(e->{JPanel panel=new JPanel(new GridLayout(3,2,8,8));panel.setBackground(bgSurface);JPasswordField oldP=new JPasswordField(),newP=new JPasswordField(),confP=new JPasswordField();oldP.setBackground(bgInput);oldP.setForeground(white);newP.setBackground(bgInput);newP.setForeground(white);confP.setBackground(bgInput);confP.setForeground(white);panel.add(lbl("Current:"));panel.add(oldP);panel.add(lbl("New:"));panel.add(newP);panel.add(lbl("Confirm:"));panel.add(confP);if(JOptionPane.showConfirmDialog(this,panel,"Change Password",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){String o=String.valueOf(oldP.getPassword()),n=String.valueOf(newP.getPassword()),cf=String.valueOf(confP.getPassword());try{PreparedStatement ps=con.prepareStatement("SELECT password FROM users WHERE id=?");ps.setInt(1,currentUserId);ResultSet rs=ps.executeQuery();rs.next();if(!rs.getString("password").equals(o)){JOptionPane.showMessageDialog(this,"Wrong password!");return;}if(!n.equals(cf)){JOptionPane.showMessageDialog(this,"Don't match!");return;}if(n.length()<8){JOptionPane.showMessageDialog(this,"Min 8 chars!");return;}ps=con.prepareStatement("UPDATE users SET password=? WHERE id=?");ps.setString(1,n);ps.setInt(2,currentUserId);ps.executeUpdate();JOptionPane.showMessageDialog(this,"Password changed!");}catch(Exception ex){JOptionPane.showMessageDialog(this,"Error: "+ex.getMessage());}}});
        p.add(c); return p;
    }

    // ========================================================================
    //  RETURN CAR
    // ========================================================================
    void doReturnCar(int rentalId, int carId) {
        try { PreparedStatement ps = con.prepareStatement(
            "SELECT r.rent_end,r.quantity,c.price_per_hour FROM rentals r JOIN cars c ON r.car_id=c.id WHERE r.id=?");
            ps.setInt(1,rentalId); ResultSet rs = ps.executeQuery(); if (!rs.next()) return;
            LocalDateTime endTime = rs.getTimestamp("rent_end").toLocalDateTime();
            double pph = rs.getDouble("price_per_hour"); int qty = rs.getInt("quantity");
            LocalDateTime now = LocalDateTime.now(); double lateFee = 0;
            if (now.isAfter(endTime)) {
                long hrs = ChronoUnit.HOURS.between(endTime, now); if (hrs < 1) hrs = 1;
                lateFee = hrs * pph * qty * 1.5;
                if (JOptionPane.showConfirmDialog(this,
                    String.format("LATE by %d hours!\nLate fee: Rs. %,.2f\n(%d car(s) x Rs.%.0f x 1.5x)\n\nProceed with return?",hrs,lateFee,qty,pph),
                    "Late Return", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) != JOptionPane.YES_OPTION) return;
            }
            PreparedStatement upd = con.prepareStatement("UPDATE rentals SET status='Returned',actual_return=?,late_fee=? WHERE id=?");
            upd.setTimestamp(1, Timestamp.valueOf(now)); upd.setDouble(2, lateFee); upd.setInt(3, rentalId);
            upd.executeUpdate();
            con.prepareStatement("UPDATE cars SET available_qty=available_qty+"+qty+" WHERE id="+carId).executeUpdate();
            refreshUserRentals(); refreshUserHistory(); refreshUserCars();
            refreshAdminRentals(); refreshAdminCars(); refreshAdminHistory(); refreshDashboard();
            String msg = "Car returned successfully!";
            if (lateFee > 0) msg += String.format("\nLate fee: Rs. %,.2f", lateFee);
            JOptionPane.showMessageDialog(this, msg); showReceipt(rentalId);
        } catch(Exception ex) { JOptionPane.showMessageDialog(this, "Error: "+ex.getMessage()); }
    }

    // ========================================================================
    //  REFRESH METHODS
    // ========================================================================
    void refreshAdmin() 
    { refreshAdminCars(); refreshAdminRentals(); refreshAdminUsers(); refreshAdminHistory(); populateUserCombo(); refreshDashboard(); }
    void refreshDashboard() 
    { try
    { Statement st = con.createStatement();
    ResultSet rs;
        rs=st.executeQuery("SELECT COUNT(*) FROM cars");
        rs.next(); int tc=rs.getInt(1);
        rs=st.executeQuery("SELECT COALESCE(SUM(available_qty),0) FROM cars");
        rs.next(); 
        int ac=rs.getInt(1);
        rs=st.executeQuery("SELECT COUNT(*) FROM rentals WHERE status='Active'");
        rs.next();
        int ar=rs.getInt(1);
        rs=st.executeQuery("SELECT COALESCE(SUM(total_price+late_fee),0) FROM rentals WHERE status IN ('Returned','Active')");
        rs.next();
        double rev=rs.getDouble(1);
        dashValCars.setText(String.valueOf(tc)); 
        dashValAvail.setText(String.valueOf(ac));
        dashValActive.setText(String.valueOf(ar));
        dashValRevenue.setText(String.format("Rs. %,.0f",rev));
        dashRecentModel.setRowCount(0);
        rs=st.executeQuery("SELECT r.id,CONCAT(c.name,' ',c.model),r.customer_name,r.rent_start,r.rent_end,r.payment_method,r.status FROM rentals r JOIN cars c ON r.car_id=c.id ORDER BY r.id DESC LIMIT 10");
        while(rs.next()) dashRecentModel.addRow(new Object[]{rs.getInt(1),rs.getString(2),rs.getString(3),rs.getTimestamp(4).toLocalDateTime().format(dtfShort),rs.getTimestamp(5).toLocalDateTime().format(dtfShort),rs.getString(6),rs.getString(7)});
    } catch(Exception e)
    { e.printStackTrace(); } }
    void refreshAdminCars()
    { adminCarModel.setRowCount(0);
    try { Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT id,name,model,price_per_hour,min_hours,max_hours,total_qty,available_qty,img_path FROM cars ORDER BY price_per_hour, id");
        while(rs.next()) adminCarModel.addRow(new Object[]{rs.getInt("id"),rs.getString("name"),rs.getString("model"),rs.getDouble("price_per_hour"),rs.getInt("min_hours"),rs.getInt("max_hours"),rs.getInt("total_qty"),rs.getInt("available_qty"),rs.getString("img_path")});
    } catch(Exception e)
    { e.printStackTrace(); } }
    void refreshAdminRentals()
    { adminRentalModel.setRowCount(0); 
    try { Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT r.id,CONCAT(c.name,' ',c.model),r.customer_name,r.contact,r.rent_start,r.rent_end,r.has_driver,r.quantity,r.total_price,r.late_fee,r.payment_method,r.payment_status,r.status,r.car_id,r.user_id FROM rentals r JOIN cars c ON r.car_id=c.id ORDER BY r.id DESC");
        while(rs.next()) adminRentalModel.addRow(new Object[]{rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getTimestamp(5).toLocalDateTime().format(dtfShort),rs.getTimestamp(6).toLocalDateTime().format(dtfShort),rs.getBoolean(7)?"Yes":"No",rs.getInt(8),String.format("%,.2f",rs.getDouble(9)),String.format("%,.2f",rs.getDouble(10)),rs.getString(11),rs.getString(12),rs.getString(13),rs.getInt(14),rs.getInt(15)});
    } catch(Exception e) { e.printStackTrace(); } }
    void refreshAdminUsers() { adminUserModel.setRowCount(0); try { Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT name,contact,email,username FROM users WHERE role='Customer' ORDER BY name");
        while(rs.next()) adminUserModel.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
    } catch(Exception e) { e.printStackTrace(); } }
    void populateUserCombo() { adminUserCombo.removeAllItems(); adminUserCombo.addItem("-- All --");
        try { Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT DISTINCT username FROM users WHERE role='Customer' ORDER BY username");
            while(rs.next()) adminUserCombo.addItem(rs.getString(1));
        } catch(Exception e) { e.printStackTrace(); } }
    void filterUserTable(String username) { adminUserModel.setRowCount(0); try {
        PreparedStatement ps = con.prepareStatement("SELECT name,contact,email,username FROM users WHERE role='Customer' AND username=?");
        ps.setString(1,username); ResultSet rs = ps.executeQuery();
        while(rs.next()) adminUserModel.addRow(new Object[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)});
    } catch(Exception e) { e.printStackTrace(); } }
    void refreshAdminHistory() { adminHistModel.setRowCount(0); try { Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT r.id,CONCAT(c.name,' ',c.model),r.customer_name,r.rent_start,r.rent_end,r.actual_return,r.total_price,r.late_fee,r.payment_method,r.status FROM rentals r JOIN cars c ON r.car_id=c.id WHERE r.status IN ('Returned','Cancelled') ORDER BY r.id DESC");
        while(rs.next()) { String ret=rs.getTimestamp(6)!=null?rs.getTimestamp(6).toLocalDateTime().format(dtfShort):"N/A";
            adminHistModel.addRow(new Object[]{rs.getInt(1),rs.getString(2),rs.getString(3),rs.getTimestamp(4).toLocalDateTime().format(dtfShort),rs.getTimestamp(5).toLocalDateTime().format(dtfShort),ret,String.format("%,.2f",rs.getDouble(7)),String.format("%,.2f",rs.getDouble(8)),rs.getString(9),rs.getString(10)}); }
    } catch(Exception e) { e.printStackTrace(); } }
    void refreshUserCars() { customerAvailModel.setRowCount(0); try { Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT id,name,model,price_per_hour,available_qty,img_path FROM cars WHERE available_qty>0 ORDER BY price_per_hour, id");
        while(rs.next()) customerAvailModel.addRow(new Object[]{rs.getInt("id"),rs.getString("name"),rs.getString("model"),rs.getDouble("price_per_hour"),rs.getInt("available_qty"),rs.getString("img_path")});
    } catch(Exception e) { e.printStackTrace(); } }
    void refreshUserRentals() { userRentalModel.setRowCount(0); try {
        PreparedStatement ps = con.prepareStatement("SELECT r.id,CONCAT(c.name,' ',c.model),r.rent_start,r.rent_end,r.has_driver,r.quantity,r.total_price,r.payment_method,r.status,r.car_id FROM rentals r JOIN cars c ON r.car_id=c.id WHERE r.user_id=? AND r.status='Active' ORDER BY r.id DESC");
        ps.setInt(1,currentUserId); ResultSet rs = ps.executeQuery();
        while(rs.next()) userRentalModel.addRow(new Object[]{rs.getInt(1),rs.getString(2),rs.getTimestamp(3).toLocalDateTime().format(dtfShort),rs.getTimestamp(4).toLocalDateTime().format(dtfShort),rs.getBoolean(5)?"Yes":"No",rs.getInt(6),String.format("%,.2f",rs.getDouble(7)),rs.getString(8),rs.getString(9),rs.getInt(10)});
    } catch(Exception e) { e.printStackTrace(); } }
    void refreshUserHistory() { userHistoryModel.setRowCount(0); try {
        PreparedStatement ps = con.prepareStatement("SELECT CONCAT(c.name,' ',c.model),r.rent_start,r.rent_end,r.actual_return,r.has_driver,r.quantity,r.total_price,r.late_fee,r.payment_method,r.status FROM rentals r JOIN cars c ON r.car_id=c.id WHERE r.user_id=? AND r.status IN ('Returned','Cancelled') ORDER BY r.id DESC");
        ps.setInt(1,currentUserId); ResultSet rs = ps.executeQuery();
        while(rs.next()) { String ret=rs.getTimestamp(4)!=null?rs.getTimestamp(4).toLocalDateTime().format(dtfShort):"N/A";
            userHistoryModel.addRow(new Object[]{rs.getString(1),rs.getTimestamp(2).toLocalDateTime().format(dtfShort),rs.getTimestamp(3).toLocalDateTime().format(dtfShort),ret,rs.getBoolean(5)?"Yes":"No",rs.getInt(6),String.format("%,.2f",rs.getDouble(7)),String.format("%,.2f",rs.getDouble(8)),rs.getString(9),rs.getString(10)}); }
    } catch(Exception e) { e.printStackTrace(); } }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
            catch(Exception e) {}
            new Carrental().setVisible(true);
        });
    }
}